// Build/app ikonu üretir: 512x512 PNG (yazı tipleri olmadan, sadece vektör + metin raster).
import { PNG } from 'pngjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const OUT = path.join(root, 'build');
fs.mkdirSync(OUT, { recursive: true });

const S = 512;
const png = new PNG({ width: S, height: S });

// Açık editoryal palet: kağıt zemin, mürekkep kenar, prova kırmızısı aksan.
const paper = [0xF7, 0xF5, 0xF0];
const ink = [0x14, 0x16, 0x1A];
const red = [0xC6, 0x3B, 0x1C];

function px(x, y, [r, g, b], a = 255) {
  if (x < 0 || y < 0 || x >= S || y >= S) return;
  const i = (S * y + x) << 2;
  png.data[i] = r;
  png.data[i + 1] = g;
  png.data[i + 2] = b;
  png.data[i + 3] = a;
}
function fillRect(x0, y0, w, h, c, a) {
  for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) px(x, y, c, a);
}
function fillCircle(cx, cy, r, c, a) {
  for (let y = Math.floor(cy - r); y <= cy + r; y++) {
    for (let x = Math.floor(cx - r); x <= cx + r; x++) {
      if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) px(x, y, c, a);
    }
  }
}
function ring(cx, cy, r, thickness, c) {
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const d = Math.hypot(x - cx, y - cy);
      if (Math.abs(d - r) <= thickness / 2) px(x, y, c);
    }
  }
}
// Yuvarlatılmış köşeli zemin (marj çizgili kart).
const RADIUS = 72;
for (let y = 0; y < S; y++) {
  for (let x = 0; x < S; x++) {
    const dx = Math.max(RADIUS - x, x - (S - 1 - RADIUS), 0);
    const dy = Math.max(RADIUS - y, y - (S - 1 - RADIUS), 0);
    if (dx * dx + dy * dy <= RADIUS * RADIUS) px(x, y, paper);
  }
}

// Mürekkep çerçeve (2px değil, 14px "kağıt kenarı").
const B = 16;
for (let y = 0; y < S; y++) {
  for (let x = 0; x < S; x++) {
    const inside = x >= B && x < S - B && y >= B && y < S - B;
    if (!inside) {
      const dx = Math.max(RADIUS - x, x - (S - 1 - RADIUS), 0);
      const dy = Math.max(RADIUS - y, y - (S - 1 - RADIUS), 0);
      if (dx * dx + dy * dy <= RADIUS * RADIUS) px(x, y, ink);
    }
  }
}

// Marj çizgisi (dikey, kırmızı) + folyo numarası motifi.
fillRect(96, 96, 6, S - 192, red);
fillCircle(120, 400, 10, red);
fillCircle(120, 436, 6, ink);

// Kulaklık / ses çemberi motifi: halka + iç disk (indirme odağı).
ring(300, 256, 120, 18, ink);
fillCircle(300, 256, 64, red);
// Aşağı ok (indir): ok diskin icinde kalir (dis kenardan en az 6px pay).
fillRect(288, 214, 24, 52, paper);
for (let i = 0; i < 36; i++) {
  const w = 24 + Math.round((48 * i) / 35);
  fillRect(300 - w / 2, 266 + i, w, 1, paper);
}

png.pack().pipe(fs.createWriteStream(path.join(OUT, 'icon.png')));
setTimeout(() => {
  const f = path.join(OUT, 'icon.png');
  console.log(fs.existsSync(f) ? `icon.png OK (${fs.statSync(f).size} bytes)` : 'icon.png FAILED');
}, 500);
