#!/usr/bin/env bash
# Debian/Ubuntu icin .deb uretir. Yalnizca Linux uzerinde calisir
# (electron-builder fpm delegasyonu Linux gerektirir).
set -euo pipefail

cd "$(dirname "$0")/.."

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "HATA: .deb yalnizca Linux uzerinde uretilebilir." >&2
  echo "Mevcut platform: $(uname -s)" >&2
  echo "Alternatif: WSL/Debian ortaminda 'npm ci && npm run dist:linux:deb' calistirin." >&2
  exit 1
fi

command -v npm >/dev/null || { echo "HATA: npm bulunamadi." >&2; exit 1; }

[[ -f build/icon.png ]] || npm run icon

npm run dist:linux:deb

echo
echo "Uretilen paketler:"
ls -1 dist/*.deb 2>/dev/null || echo "  (deb bulunamadi - dist/ altina bakin)"
