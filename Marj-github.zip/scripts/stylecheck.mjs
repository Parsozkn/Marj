import { _electron as electron } from 'playwright';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const ELECTRON_BIN = path.join(root, 'node_modules', 'electron', 'dist', process.platform === 'win32' ? 'electron.exe' : 'Electron');

const app = await electron.launch({
  executablePath: ELECTRON_BIN,
  args: [root],
  cwd: root,
  env: { ...process.env, MARJ_TEST: '1' },
});
const page = await app.firstWindow();
await page.waitForSelector('#view-download', { state: 'visible', timeout: 20000 });

const out = await page.evaluate(() => {
  const cs = (sel, prop) => getComputedStyle(document.querySelector(sel))[prop];
  const before = getComputedStyle(document.querySelector('#queueEmpty'), '::before');
  const input = document.querySelector('#linkInput');
  input.focus();
  const focusShadow = getComputedStyle(input).boxShadow;
  return {
    bosDurumCizgi: { content: before.content, bg: before.backgroundColor, w: before.width, h: before.height },
    girisOdakHalkasi: { boxShadow: focusShadow, outlineColor: getComputedStyle(input).outlineColor },
    birincilButonGolge: getComputedStyle(document.querySelector('#analyzeBtn')).boxShadow,
    segmentZemin: getComputedStyle(document.querySelector('.segmented')).backgroundColor,
    pasifButon: (() => {
      const b = document.querySelector('#analyzeBtn');
      return { bg: getComputedStyle(b).backgroundColor, color: getComputedStyle(b).color, shadow: getComputedStyle(b).boxShadow };
    })(),
    kaydirmaKokOzellikleri: typeof document.documentElement.style.scrollbarColor !== 'undefined' || true,
  };
});
console.log(JSON.stringify(out, null, 2));
await app.close();
