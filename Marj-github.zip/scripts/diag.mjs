// Tanilama: uygulama icerisinden analyze cagrisini dogrudan yapar ve sonucu yazar.
import { _electron as electron } from 'playwright';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ELECTRON_BIN = path.join(root, 'node_modules', 'electron', 'dist', process.platform === 'win32' ? 'electron.exe' : 'Electron');
const URL_ = process.argv[2] || 'https://www.youtube.com/watch?v=jNQXAC9IVRw';

const app = await electron.launch({
  executablePath: ELECTRON_BIN,
  args: [root],
  cwd: root,
  env: { ...process.env, MARJ_TEST: '1' },
});
const page = await app.firstWindow();
page.on('console', (m) => console.log('[console:' + m.type() + ']', m.text().slice(0, 300)));
page.on('pageerror', (e) => console.log('[pageerror]', e.message));
await page.waitForSelector('#view-download', { state: 'visible', timeout: 20000 });

const st = await page.evaluate(() => window.marj.state());
console.log('bins:', JSON.stringify(st.bins));
console.log('settings:', JSON.stringify({ cookies: st.settings.cookies, outDir: st.settings.outDir }));

const t0 = Date.now();
try {
  const res = await page.evaluate((u) => window.marj.analyze(u), URL_);
  console.log('ANALIZ OK', Date.now() - t0, 'ms ->', JSON.stringify(res).slice(0, 400));
} catch (e) {
  console.log('ANALIZ HATA', Date.now() - t0, 'ms ->', String(e.message || e).slice(0, 800));
}

// UI akisi de denensin
await page.fill('#linkInput', URL_);
await page.click('#analyzeBtn');
for (let i = 0; i < 40; i++) {
  const s = await page.evaluate(() => ({
    loading: !document.querySelector('#analyzeLoading').hidden,
    error: !document.querySelector('#analyzeError').hidden,
    errText: (document.querySelector('#analyzeErrorText') || {}).textContent || '',
    preview: !document.querySelector('#preview').hidden,
  }));
  if (s.preview || s.error) { console.log('UI DURUMU', JSON.stringify(s)); break; }
  await new Promise((r) => setTimeout(r, 1000));
}
await new Promise((r) => setTimeout(r, 400));
console.log('ODAK:', JSON.stringify(await page.evaluate(() => {
  const a = document.activeElement;
  return { id: a && a.id, tag: a && a.tagName, startVisible: !!document.querySelector('#startBtn') && document.querySelector('#startBtn').offsetParent !== null };
})));

await app.close();
process.exit(0);
