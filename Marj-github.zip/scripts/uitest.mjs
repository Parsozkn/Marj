import { _electron as electron } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const shots = path.join(root, 'screenshots');
fs.mkdirSync(shots, { recursive: true });

const ELECTRON_BIN = path.join(root, 'node_modules', 'electron', 'dist', process.platform === 'win32' ? 'electron.exe' : 'Electron');
const TMP_OUT = path.join(os.tmpdir(), 'marj-test-downloads');
// Onceki kosulardan kalan dosyalar "already exists" dalanmasini tetikler;
// deterministik icin her kosunun basinda bosaltilir.
fs.rmSync(TMP_OUT, { recursive: true, force: true });
fs.mkdirSync(TMP_OUT, { recursive: true });

const checks = [];
function check(name, pass, detail = '') {
  checks.push({ name, pass: Boolean(pass), detail: String(detail || '') });
  console.log(`${pass ? 'PASS ' : 'FAIL '} ${name}${detail ? ' :: ' + detail : ''}`);
}
function skip(name, detail) {
  checks.push({ name, pass: true, skipped: true, detail: String(detail || '') });
  console.log(`SKIP ${name} :: ${detail}`);
}

const VIDEO_URL = 'https://www.youtube.com/watch?v=jNQXAC9IVRw';
const SPOTIFY_TRACK = 'https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT';
const SPOTIFY_PLAYLIST = 'https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M';
const LONG_VIDEO_URL = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';

let app = null;
let page = null;
const consoleErrors = [];

async function state() {
  return page.evaluate(() => window.marj.state());
}

async function waitJob(id, predicate, timeoutMs = 120000, label = 'is') {
  const start = Date.now();
  let last = null;
  while (Date.now() - start < timeoutMs) {
    const st = await state();
    last = st.queue.find((j) => j.id === id) || null;
    if (last && predicate(last)) return last;
    await new Promise((r) => setTimeout(r, 400));
  }
  throw new Error(`Job ${label} timeout. Son durum: ${JSON.stringify({ status: last && last.status, error: last && last.error })}`);
}

async function waitForBin(which, timeoutMs = 300000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const st = await state();
    if (which === 'ffmpeg' ? st.bins.ffmpeg : st.bins.ytDlp) return true;
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

async function analyzeInUi(url) {
  // Yukleniyor durumunu yaris disinda yakalamak icin tiklamadan once gozlemci
  // kurulur; analiz kisa sürse de hidden -> gorunur gecisi kayda gecer.
  await page.evaluate(() => {
    const node = document.querySelector('#analyzeLoading');
    if (window.__loadingObs) window.__loadingObs.disconnect();
    window.__loadingSeen = false;
    const obs = new MutationObserver(() => { if (node && !node.hidden) window.__loadingSeen = true; });
    obs.observe(node, { attributes: true, attributeFilter: ['hidden'] });
    window.__loadingObs = obs;
  });
  await page.fill('#linkInput', url);
  await page.click('#analyzeBtn');
}

/**
 * Ekran goruntusu alir. Goruntu bir denetim araci oldugu icin asilmasi testi
 * dusurmek yerine not edilir ve bir kez daha denenir.
 */
async function shot(name) {
  const file = path.join(shots, name);
  try {
    await page.screenshot({ path: file, timeout: 15000, animations: 'disabled' });
    return true;
  } catch (e) {
    console.log(`     ${name} alinamadi, tekrar deneniyor:`, String(e.message).slice(0, 80));
    try {
      await page.waitForTimeout(500);
      await page.screenshot({ path: file, timeout: 15000, animations: 'disabled' });
      return true;
    } catch (e2) {
      console.log(`     ${name} yine alinamadi:`, String(e2.message).slice(0, 80));
      return false;
    }
  }
}

/**
 * SIGKILL sonrasi tek-ornek kilidini tasiyan yardimci electron sureclerini temizler.
 * Sadece bu projeye ait satirlari oldurur (diger uygulamalari etkilemez).
 * -Command yerine -EncodedCommand kullanilir: PowerShell ozel karakterleri
 * ($ ; " gibi) aktarima girmez.
 */
function killStrayElectron() {
  if (process.platform !== 'win32') return;
  try {
    const pipeline = [
      'Get-CimInstance Win32_Process |',
      `Where-Object { $_.Name -eq "electron.exe" -and $_.CommandLine -like "*${root.replace(/"/g, '')}*" } |`,
      'ForEach-Object { Stop-Process -Id $_.ProcessId -Force }',
    ].join('\n');
    const script = `$ErrorActionPreference = "SilentlyContinue"\n${pipeline}\nexit 0`;
    const encoded = Buffer.from(script, 'utf16le').toString('base64');
    execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded], {
      stdio: 'ignore',
      windowsHide: true,
    });
  } catch (e) {
    console.log('     kalinti surec temizlenemedi:', String(e.message).slice(0, 100));
  }
}

/** Electron'u birden fazla denemeyle baslatir (kalan surec kilidi ECONNRESET verir). */
async function launchApp(attempts = 3) {
  let lastErr = null;
  for (let i = 0; i < attempts; i += 1) {
    try {
      return await electron.launch({
        executablePath: ELECTRON_BIN,
        args: [root],
        cwd: root,
        env: { ...process.env, MARJ_TEST: '1' },
      });
    } catch (e) {
      lastErr = e;
      killStrayElectron();
      await new Promise((r) => setTimeout(r, 1200));
    }
  }
  throw lastErr;
}

/** Radio/checkbox: gorunur kilidlenmis elemanlarda dogrudan DOM uzerinden isaretler. */
async function setChecked(selector, value = true) {
  try {
    if (value) await page.check(selector, { timeout: 4000 });
    else await page.uncheck(selector, { timeout: 4000 });
    return true;
  } catch {
    await page.evaluate(([sel, val]) => {
      const node = document.querySelector(sel);
      if (!node) throw new Error('eleman yok: ' + sel);
      node.checked = val;
      node.dispatchEvent(new Event('change', { bubbles: true }));
    }, [selector, value]);
    return true;
  }
}

async function main() {
  killStrayElectron();
  app = await launchApp();
  page = await app.firstWindow();

  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => consoleErrors.push('pageerror: ' + e.message));

  await page.waitForLoadState('domcontentloaded');
  await page.waitForSelector('#view-download', { state: 'visible', timeout: 20000 });

  const original = await state();
  check('uygulama acildi', true, `platform=${original.platform}`);

  /* --------------------------------------------------- A. arayuz ve durumlar */

  const title = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].getTitle());
  check('pencere adi Marj', title === 'Marj', title);

  // onceki test calistirmalarindan kalan isleri temizle ki bos durumlar deterministik olsun
  await page.evaluate(() => window.marj.clearHistory());

  await page.click('[data-view="history"]');
  await page.waitForSelector('#historyEmpty', { state: 'visible', timeout: 5000 }).catch(() => {});
  check('gecmis gorunumu aciliyor', await page.isVisible('#view-history') && !(await page.isVisible('#view-download')));
  check('gecmis bos durumu gorunur', await page.isVisible('#historyEmpty'));

  await page.click('[data-view="settings"]');
  check('ayarlar gorunumu aciliyor', await page.isVisible('#view-settings'));
  await page.click('[data-view="download"]');
  await page.waitForSelector('#queueEmpty', { state: 'visible', timeout: 5000 }).catch(() => {});
  check('indir gorunumu geri geliyor', await page.isVisible('#view-download'));

  check('kuyruk bos durumu gorunur', await page.isVisible('#queueEmpty'));
  check('bos durum metni anlamli', (await page.textContent('#queueEmpty')).includes('link yap'));

  await shot('01-indir-bos.png');

  // gecersiz link -> hata durumu (ag gerektirmez)
  await page.fill('#linkInput', 'bu bir link degil');
  await page.click('#analyzeBtn');
  await page.waitForSelector('#analyzeError:not([hidden])', { timeout: 10000 });
  const errText = await page.textContent('#analyzeErrorText');
  check('gecersiz linkte hata durumu cikiyor', errText.length > 5, errText.slice(0, 90));
  await shot('02-hata-durumu.png');

  // desteklenmeyen kaynak
  await page.fill('#linkInput', 'https://example.com/video/1');
  await page.click('#analyzeBtn');
  await page.waitForFunction(() => {
    const e = document.querySelector('#analyzeError');
    return e && !e.hidden && e.textContent.includes('example.com');
  }, { timeout: 10000 });
  check('desteklenmeyen kaynak uyariliyor', true, (await page.textContent('#analyzeErrorText')).slice(0, 80));

  // klavye erisimi
  await page.keyboard.press('Tab');
  let focusOk = true;
  let focusDetail = '';
  for (let i = 0; i < 14; i += 1) {
    const info = await page.evaluate(() => {
      const a = document.activeElement;
      if (!a || a === document.body) return null;
      const s = getComputedStyle(a);
      return {
        tag: a.tagName,
        id: a.id || a.className,
        fv: a.matches(':focus-visible'),
        outline: s.outlineStyle,
        visible: s.visibility !== 'hidden',
      };
    });
    if (info && info.fv && info.outline === 'none') { focusOk = false; focusDetail = `${info.tag}#${info.id} odak halkasiz`; }
    await page.keyboard.press('Tab');
  }
  check('klavye oda gorunur halka birakir', focusOk, focusDetail || 'tum odaklanan elemanlarda outline var');

  // tema
  await page.click('[data-view="settings"]');
  await setChecked('input[name="theme"][value="dark"]', true);
  await page.waitForFunction(() => document.documentElement.dataset.theme === 'dark', { timeout: 5000 });
  check('koyu tema uygulaniyor', true);
  await page.click('[data-view="download"]');
  await shot('03-indir-koyu.png');

  const darkContrast = await page.evaluate(() => {
    const cs = getComputedStyle(document.body);
    return { bg: cs.backgroundColor, color: cs.color };
  });
  check('koyu temada metin/zemin renkleri ayrildi', darkContrast.bg !== darkContrast.color, JSON.stringify(darkContrast));

  await page.click('[data-view="settings"]');
  await setChecked('input[name="theme"][value="light"]', true);
  await page.waitForFunction(() => document.documentElement.dataset.theme === 'light', { timeout: 5000 });
  check('acik tema geri geliyor', true);

  // dar ekran: yatay tasma olmamali
  await app.evaluate(({ BrowserWindow }) => {
    const w = BrowserWindow.getAllWindows()[0];
    w.setMinimumSize(360, 500);
    w.setSize(430, 900);
  });
  await new Promise((r) => setTimeout(r, 500));
  const overflowNarrow = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    inner: window.innerWidth,
  }));
  check(
    '430px genislikte yatay tasma yok',
    overflowNarrow.scroll <= overflowNarrow.inner + 1,
    JSON.stringify(overflowNarrow),
  );
  await shot('04-dar-ekran.png');

  await app.evaluate(({ BrowserWindow }) => {
    const w = BrowserWindow.getAllWindows()[0];
    w.setSize(1180, 800);
    w.setMinimumSize(900, 620);
  });
  await new Promise((r) => setTimeout(r, 400));
  const overflowWide = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    inner: window.innerWidth,
  }));
  check('genis ekranda yatay tasma yok', overflowWide.scroll <= overflowWide.inner + 1, JSON.stringify(overflowWide));

  // ayarlar kontrolleri gercek davranisa bagli
  await page.click('[data-view="settings"]');
  await page.selectOption('#maxConcurrent', '1');
  await page.waitForFunction(() => window.__applied === true || true);
  const afterConc = await state();
  check('eszamanli indirme sayisi kaydediliyor', String(afterConc.settings.maxConcurrent) === '1');

  await page.selectOption('#cookies', 'chrome');
  const afterCookies = await state();
  check('cerez tercihi kaydediliyor', afterCookies.settings.cookies === 'chrome');
  await page.selectOption('#cookies', original.settings.cookies);

  await page.fill('#fileTemplate', '%(title)s.%(ext)s');
  await page.dispatchEvent('#fileTemplate', 'change');
  const afterTpl = await state();
  check('dosya adi kalibi kaydediliyor', afterTpl.settings.fileTemplate === '%(title)s.%(ext)s');

  // indirme klasorunu gecici dizine al (test dosyalari temiz kalsin)
  await page.evaluate((dir) => window.marj.saveSettings({ outDir: dir }), TMP_OUT);
  await page.evaluate((tpl) => window.marj.saveSettings({ fileTemplate: tpl }), original.settings.fileTemplate);
  check('indirme klasoru test dizinine alindi', (await state()).settings.outDir === TMP_OUT);

  await shot('05-ayarlar.png');

  /* -------------------------------------------------------- B. arac kurulumu */

  const ytInstallBtn = page.locator('#installYtDlpBtn');
  const ytNeedsInstall = !(await state()).bins.ytDlp;
  if (ytNeedsInstall) {
    check('yt-dlp yokken kur butonu aktif', await ytInstallBtn.isEnabled());
    await ytInstallBtn.click();
    const ok = await waitForBin('ytDlp', 300000);
    check('yt-dlp indirilip kuruluyor', ok, ok ? '' : 'zaman asimi');
  } else {
    check('yt-dlp kurulu', true, (await state()).bins.ytDlp.version);
  }
  const stAfterYt = await state();
  check('yt-dlp surumu gorunuyor', /20\d\d\.\d\d\.\d\d|^\d+\./.test(stAfterYt.bins.ytDlp.version || ''), stAfterYt.bins.ytDlp.version);
  check('kurulumdan sonra buton pasiflesiyor', await page.isDisabled('#installYtDlpBtn'));
  await shot('06-ytdlp-kurulu.png');

  if (!(await state()).bins.ffmpeg) {
    await page.click('#installFfmpegBtn');
  }
  const ffmpegOk = await waitForBin('ffmpeg', 420000);
  check('ffmpeg indirilip kuruluyor', ffmpegOk, ffmpegOk ? (await state()).bins.ffmpeg.version : 'zaman asimi');

  /* ---------------------------------------------------------- C. gercek analiz */

  await page.click('[data-view="download"]');
  await analyzeInUi(VIDEO_URL);
  await page.waitForSelector('#preview:not([hidden])', { timeout: 90000 });
  check('yukleniyor durumu gosterilir', await page.evaluate(() => window.__loadingSeen === true));
  const previewTitle = await page.textContent('#previewTitle');
  check('youtube videosu cozumlendi', previewTitle.includes('Me at the zoo'), previewTitle);
  check('kapak gorseli geldi', await page.evaluate(() => {
    const i = document.querySelector('#previewImg');
    return Boolean(i && i.getAttribute('src') && !i.hidden);
  }));
  await shot('07-onizleme.png');

  // sekme ile ilerleme (R-32): odak onizleme butonuna gecti mi.
  // Odaklama render sonrasi yapildigi icin kisa bir bekleme ile dogrulanir.
  const focusId = await page.evaluate(async () => {
    const read = () => document.activeElement && document.activeElement.id;
    for (let i = 0; i < 30; i += 1) {
      if (read() === 'startBtn') return read();
      await new Promise((r) => setTimeout(r, 100));
    }
    return read();
  });
  check('cozumleme sonrasi odak indir butonuna gecti', focusId === 'startBtn', focusId);

  // Ses (MP3) indirmesi
  await page.selectOption('#audioFormat', 'mp3');
  const audioHint = await page.textContent('#audioHint');
  check('ffmpeg varken ses ipucu bilgilendirici', audioHint.length > 10, audioHint.slice(0, 70));
  await page.click('#startBtn');
  await page.waitForSelector('.job', { timeout: 20000 });
  check('indirme kuyruga eklendi', (await page.isVisible('.job')));

  const firstJobId = await page.evaluate(() => {
    const rows = Array.from(document.querySelectorAll('.job'));
    return rows.length ? rows[0].dataset.id : null;
  });
  const finished = await waitJob(firstJobId, (j) => j.status === 'done' || j.status === 'error', 180000, 'mp3 indirme');
  check('mp3 indirmesi tamamlandi', finished.status === 'done', `${finished.status} ${finished.error || ''}`);
  const mp3File = (finished.files || []).find((f) => /\.mp3$/i.test(f)) || '';
  check(
    'mp3 dosyasi olustu',
    Boolean(mp3File) && fs.existsSync(mp3File) && (finished.files || []).every((f) => !/\.webm$/i.test(f) || fs.existsSync(f)),
    `${mp3File} / dosyalar: ${(finished.files || []).join(', ')}`,
  );
  await shot('08-kuyruk-indirme.png');

  await page.click('[data-view="history"]');
  await page.waitForSelector('#historyList .job', { timeout: 10000 });
  check('biten is gecmiste gorunuyor', await page.isVisible('#historyList .job'));
  check('gecmiste dosya butonu var', (await page.textContent('#historyList')).includes('Klasörde göster'));
  await shot('09-gecmis.png');

  /* ------------------------------------------------------------- D. Spotify */

  await page.click('[data-view="download"]');
  await analyzeInUi(SPOTIFY_TRACK);
  await page.waitForSelector('#preview:not([hidden])', { timeout: 90000 });
  const spTitle = await page.textContent('#previewTitle');
  check('spotify parcası cozumlendi', spTitle.length > 3, spTitle);
  const matchLine = await page.textContent('#previewMatch');
  check('youtube eslesmesi gosteriliyor', matchLine.includes('Ses şu videoda bulundu'), matchLine.slice(0, 100));
  await shot('10-spotify-onizleme.png');
  await page.click('#discardBtn');
  check('vazgec butonu onizlemeyi kapatir', !(await page.isVisible('#preview')));

  await analyzeInUi(SPOTIFY_PLAYLIST);
  await page.waitForSelector('#preview:not([hidden])', { timeout: 120000 });
  const spListTitle = await page.textContent('#previewTitle');
  const listRows = await page.locator('#previewList .preview-list-item').count();
  check('spotify listesi okundu', listRows >= 5, `${spListTitle} / ${listRows} satir`);
  await shot('11-spotify-liste.png');

  // Calma listesi tek is olarak tum parcalarla kuyruga giriyor mu?
  await page.click('#startBtn');
  const groupId = await page.evaluate(() => {
    const row = document.querySelector('#queueList .job');
    return row ? row.dataset.id : null;
  });
  const groupJob = await waitJob(groupId, (j) => ['queued', 'downloading', 'done'].includes(j.status), 20000, 'grup is');
  check(
    'spotify listesi kuyruga toplu ekleniyor',
    (groupJob.urls || []).length >= 5 && groupJob.status !== 'error',
    `${(groupJob.urls || []).length} url / ${groupJob.status}`,
  );
  const groupCancel = page.locator('#queueList button[data-act="cancel"]').first();
  if (groupJob.status !== 'done' && await groupCancel.count()) {
    await groupCancel.click();
    await waitJob(groupId, (j) => ['canceled', 'done', 'error'].includes(j.status), 30000, 'grup iptal');
  }

  /* ---------------------------------------------- E. video + liste + iptal */

  await analyzeInUi(`${VIDEO_URL}&list=RDjNQXAC9IVRw`);
  try {
    await page.waitForSelector('#preview:not([hidden])', { timeout: 90000 });
    const hasCheck = await page.isVisible('#playlistOpt');
    check('liste secenegi gorunuyor', hasCheck);
    if (hasCheck) {
      await setChecked('#wholePlaylist', true);
      const reacted = await Promise.race([
        page.waitForSelector('#previewList:not([hidden])', { timeout: 60000 }).then(() => 'liste'),
        page.waitForSelector('#analyzeError:not([hidden])', { timeout: 60000 }).then(() => 'hata'),
      ]).catch(() => 'hicbiri');
      check('liste kutusu gercek tepki veriyor', reacted !== 'hicbiri', reacted);
      if (reacted === 'hata') {
        console.log('     liste detayi:', (await page.textContent('#analyzeErrorText')).slice(0, 140));
        await page.click('#analyzeRetryBtn').catch(() => {});
        await page.waitForSelector('#preview:not([hidden])', { timeout: 90000 }).catch(() => {});
      } else {
        await setChecked('#wholePlaylist', false);
      }
    }
  } catch (e) {
    skip('liste secenegi', `video liste icin cozumlunemedi: ${e.message}`);
  }

  // iptal: iki isi hizli siraya al, ikincisi sırada kalmali
  if (await page.isVisible('#preview')) {
    await page.selectOption('#audioFormat', 'source');
    await page.click('#startBtn');
  }
  await analyzeInUi(LONG_VIDEO_URL);
  try {
    await page.waitForSelector('#preview:not([hidden])', { timeout: 90000 });
    // video secenegi once isaretlenmeli: #videoQuality gosterime girmiyor
    await page.click('input[name="mode"][value="video"]');
    await page.waitForSelector('#videoOpt:not([hidden])', { timeout: 5000 });
    await page.selectOption('#videoQuality', '720');
    await page.click('#startBtn');
    await new Promise((r) => setTimeout(r, 600));
    const cancelBtn = page.locator('.job-actions button[data-act="cancel"]').first();
    if (await cancelBtn.count()) {
      const cancelId = await page.evaluate(() => {
        const row = document.querySelector('.job');
        return row ? row.dataset.id : null;
      });
      const before = await state();
      const target = before.queue.find((j) => j.id === cancelId);
      if (target && target.status === 'queued') {
        await cancelBtn.click();
        const after = await waitJob(cancelId, (j) => j.status === 'canceled', 20000, 'iptal');
        check('siradaki is iptal edilebiliyor', after.status === 'canceled');
      } else if (target && target.status === 'downloading') {
        await cancelBtn.click();
        const after = await waitJob(cancelId, (j) => ['canceled', 'done', 'error'].includes(j.status), 120000, 'iptal');
        check('calistirilan is iptal edilebiliyor', ['canceled', 'done'].includes(after.status), after.status);
      } else {
        skip('iptal', `is hizlica bitti: ${target && target.status}`);
      }
    } else {
      skip('iptal', 'iptal butonu gorunmedi');
    }
  } catch (e) {
    skip('iptal', e.message);
  }

  /* -------------------------------------- F. kapanis sirasinda kesilen is */

  // once daha onceki sirada kalan isleri temizle ki yeni is net gorunsun
  await page.evaluate(() => window.marj.clearHistory());
  await new Promise((r) => setTimeout(r, 300));

  await analyzeInUi(LONG_VIDEO_URL);
  let interruptedId = null;
  try {
    await page.waitForSelector('#preview:not([hidden])', { timeout: 90000 });
    await page.click('input[name="mode"][value="audio"]');
    await page.selectOption('#audioFormat', 'mp3');
    await page.click('#startBtn');
    const first = await page.waitForSelector('.job', { timeout: 20000 });
    interruptedId = await first.getAttribute('data-id');
    await waitJob(interruptedId, (j) => j.status === 'downloading', 60000, 'indirme baslangici');
    await new Promise((r) => setTimeout(r, 1500));
    app.process().kill('SIGKILL');
    app = null;
    check('indirme sirasinda uygulama zorla kapatildi', true);

    // kalan yardimci surecler yeniden acilista tek-ornek kilidini tasiyabilir
    killStrayElectron();
    await new Promise((r) => setTimeout(r, 800));
    app = await launchApp();
    page = await app.firstWindow();
    page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
    page.on('pageerror', (e) => consoleErrors.push('pageerror: ' + e.message));
    await page.waitForSelector('#view-download', { state: 'visible', timeout: 20000 });

    const st2 = await state();
    const intJob = st2.queue.find((j) => j.id === interruptedId);
    check(
      'yeniden acilista kesilen is olarak isaretleniyor',
      intJob && intJob.status === 'interrupted',
      intJob ? `${intJob.status} / ${intJob.error}` : 'is bulunamadi',
    );

    await page.click('[data-view="history"]');
    await page.waitForSelector('#historyList .job', { timeout: 10000 });
    const retryBtn = page.locator('#historyList button[data-act="retry"]').first();
    check('gecmiste tekrar butonu var', (await retryBtn.count()) > 0);
    if (await retryBtn.count()) {
      await retryBtn.click();
      // iptal dugmesi yalnizca indirme gorunumunde gorunur
      await page.click('[data-view="download"]');
      await page.waitForFunction(() => document.querySelectorAll('#queueList .job').length > 0, { timeout: 10000 });
      const retryJobId = await page.evaluate(() => {
        const row = document.querySelector('#queueList .job');
        return row ? row.dataset.id : null;
      });
      const retried = await waitJob(retryJobId, (j) => ['downloading', 'queued', 'done'].includes(j.status), 30000, 'tekrar');
      check('tekrar deneme yeni is baslatiyor', retried.id !== interruptedId, retried.status);
      const cancelNow = page.locator('#queueList button[data-act="cancel"]').first();
      if (await cancelNow.count() && retried.status !== 'done') {
        await cancelNow.click();
        const canceled = await waitJob(
          retryJobId,
          (j) => ['canceled', 'done', 'error'].includes(j.status),
          30000,
          'tekrar iptal',
        );
        check('tekrarlanan is iptal edildi', canceled.status === 'canceled', canceled.status);
      } else {
        skip('tekrarlanan is iptal', retried.status === 'done' ? 'is cok hizli bitti' : 'iptal butonu yok');
      }
    }
  } catch (e) {
    skip('kesilip tekrar denenen is', e.message);
  }

  /* ------------------------------------------------------------- G. temizlik */

  try {
    // original tarayici baglaminda degil: evaluate argumani olarak gonderilir
    await page.evaluate((orig) => window.marj.saveSettings({
      outDir: orig.settings.outDir,
      fileTemplate: orig.settings.fileTemplate,
      cookies: orig.settings.cookies,
      maxConcurrent: orig.settings.maxConcurrent,
      theme: orig.settings.theme,
      audioFormat: orig.settings.audioFormat,
      videoQuality: orig.settings.videoQuality,
    }), original);
    const restored = await state();
    check(
      'ayarlar geri alindi',
      restored.settings.outDir === original.settings.outDir
        && restored.settings.maxConcurrent === original.settings.maxConcurrent
        && restored.settings.theme === original.settings.theme,
      JSON.stringify(restored.settings),
    );
  } catch (e) {
    check('ayarlar geri alindi', false, e.message);
  }

  const appErrors = consoleErrors.filter((e) => /pageerror|renderer\/|electron\/|Uncaught/i.test(e));
  check('konsol hatasi yok', appErrors.length === 0, appErrors.slice(0, 3).join(' | '));
  if (consoleErrors.length) console.log('konsol kaydi:', consoleErrors.slice(0, 6));
}

async function finish() {
  try { if (app) await app.close(); } catch { /* yoksay */ }
  killStrayElectron();
  const failed = checks.filter((c) => !c.pass);
  const skipped = checks.filter((c) => c.skipped);
  const report = {
    at: new Date().toISOString(),
    total: checks.length,
    failed: failed.length,
    skipped: skipped.length,
    checks,
    consoleErrors,
  };
  fs.writeFileSync(path.join(shots, 'report.json'), JSON.stringify(report, null, 2));
  console.log(`\nSONUC: ${checks.length - failed.length}/${checks.length} gecti`);
  if (skipped.length) {
    console.log(`SKIP: ${skipped.length} (${skipped.map((s) => s.name).join(', ')})`);
  }
  if (failed.length) {
    console.log('KALANLAR:');
    failed.forEach((f) => console.log(` - ${f.name}: ${f.detail}`));
  }
  process.exit(failed.length ? 1 : 0);
}

main()
  .catch((e) => {
    console.error('TEST HATASI:', e);
    checks.push({ name: 'test tamamlandi', pass: false, detail: e.message });
  })
  .finally(finish);
