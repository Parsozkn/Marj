'use strict';

const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const providers = require('./providers');
const engine = require('./engine');

let win = null;
let settings = null;
let bins = { ytDlp: null, ffmpeg: null };
let queue = [];
let active = 0;
let persistTimer = null;

// Test modunda (MARJ_TEST=1) gercek kullanici profili kirletilmez: ayarlar,
// gecmis ve indirilen araclar gecici bir profile yazilir. Dizin sabittir ki
// testler arasi yt-dlp/FFmpeg tekrar indirilmesin.
if (process.env.MARJ_TEST) {
  app.setPath('userData', path.join(os.tmpdir(), 'marj-test-profile'));
}

function settingsFile() { return path.join(app.getPath('userData'), 'settings.json'); }
function queueFile() { return path.join(app.getPath('userData'), 'queue.json'); }

function defaultSettings() {
  return {
    outDir: path.join(app.getPath('downloads'), 'Marj'),
    audioFormat: 'mp3',
    videoQuality: '1080',
    cookies: 'none',
    theme: 'light',
    ytDlpPath: '',
    ffmpegPath: '',
    fileTemplate: '%(title)s.%(ext)s',
    embedMeta: true,
    maxConcurrent: 2,
  };
}

function loadSettings() {
  const base = defaultSettings();
  try {
    const raw = JSON.parse(fs.readFileSync(settingsFile(), 'utf8'));
    settings = { ...base, ...raw };
  } catch {
    settings = base;
  }
}

function saveSettings(patch) {
  Object.assign(settings, patch || {});
  try { fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2)); } catch { /* yoksay */ }
  send('settings', settings);
}

function loadQueue() {
  try {
    const raw = JSON.parse(fs.readFileSync(queueFile(), 'utf8'));
    if (Array.isArray(raw)) {
      queue = raw.map((j) => {
        const job = { ...j, handle: null };
        if (['downloading', 'queued', 'post', 'analyzing'].includes(job.status)) {
          job.status = 'interrupted';
          job.error = 'Uygulama kapanırken indirme kesildi.';
          job.finishedAt = Date.now();
        }
        job.progress = job.progress || null;
        job.files = job.files || [];
        return job;
      });
    }
  } catch {
    queue = [];
  }
}

function persistNow() {
  const slim = queue.map(({ handle, ...rest }) => rest);
  try { fs.writeFileSync(queueFile(), JSON.stringify(slim)); } catch { /* yoksay */ }
}

function persist() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(persistNow, 800);
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

function uid() {
  return `j${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

async function refreshBins() {
  const loc = await engine.locate({ settings });
  bins = { ytDlp: loc.ytDlp, ffmpeg: loc.ffmpeg };
  send('bins', bins);
  return bins;
}

/* ------------------------------------------------------------------ analiz */

function flatEntryThumb(entry) {
  if (entry.thumbnail) return entry.thumbnail;
  if (entry.id) return `https://i.ytimg.com/vi/${entry.id}/hqdefault.jpg`;
  return null;
}

function playlistResult(d, info) {
  const entries = (info.entries || []).filter(Boolean);
  const items = entries.slice(0, 500).map((e) => ({
    id: e.id,
    title: e.title || e.id || '',
    artist: e.uploader || e.channel || '',
    duration: e.duration || null,
    thumb: flatEntryThumb(e),
  }));
  return {
    kind: 'playlist',
    source: d.source,
    sourceLabel: d.sourceLabel,
    url: d.url,
    title: info.title || 'Çalma listesi',
    artist: info.uploader || info.channel || '',
    thumb: info.thumbnail || (items[0] && items[0].thumb) || null,
    count: info.playlist_count || entries.length,
    items,
    itemsTotal: entries.length,
  };
}

async function analyzeUrl(raw) {
  let d = providers.detect(raw);
  if (!d.ok) throw new Error(d.reason);
  if (d.needsResolve) {
    const resolved = await providers.resolveRedirect(d.url);
    d = providers.detect(resolved);
    if (!d.ok) throw new Error(d.reason);
  }

  if (!bins.ytDlp) await refreshBins();
  if (!bins.ytDlp) {
    throw new Error('yt-dlp kurulu değil. Ayarlar sayfasından resmi yayını indirip kurabilirsiniz.');
  }

  if (d.source === 'spotify') {
    if (d.playlistish) {
      const meta = await providers.spotifyMeta(d.url).catch(() => null);
      const items = await providers.enumerateSpotify(d.url);
      return {
        kind: 'group',
        source: 'spotify',
        sourceLabel: 'Spotify',
        listType: d.type,
        url: d.url,
        title: (meta && meta.title) || d.url,
        thumb: (meta && meta.thumb) || null,
        artist: '',
        count: items.length,
        items,
      };
    }
    const meta = await providers.spotifyMeta(d.url);
    if (!meta.title) throw new Error('Spotify parçası okunamadı.');
    const match = await providers.youtubeSearch(meta.title, { ytdlp: bins.ytDlp });
    return {
      kind: 'track',
      source: 'spotify',
      sourceLabel: 'Spotify',
      url: d.url,
      title: meta.title,
      artist: '',
      thumb: meta.thumb,
      match,
    };
  }

  if (d.type === 'playlist') {
    const info = await engine.analyze({
      urls: [d.url],
      mode: 'playlist',
      bin: bins.ytDlp,
      cookies: settings.cookies,
    });
    return playlistResult(d, info);
  }

  const info = await engine.analyze({
    urls: [d.videoUrl || d.url],
    mode: 'single',
    bin: bins.ytDlp,
    cookies: settings.cookies,
  });
  if (!info || !info.id) throw new Error('Video bilgisi okunamadı.');
  return {
    kind: 'video',
    source: d.source,
    sourceLabel: d.sourceLabel,
    url: d.url,
    id: info.id,
    title: info.title || 'Başlıksız',
    artist: info.uploader || info.channel || '',
    thumb: info.thumbnail,
    duration: info.duration || null,
    hasPlaylistChoice: d.hasPlaylistChoice,
    playlistUrl: d.playlistUrl,
    playlistTitle: null,
  };
}

/* -------------------------------------------------------------------- kuyruk */

function searchQuery(item) {
  const title = item.title || '';
  const artist = item.artist || '';
  return `${title} ${artist}`.trim();
}

function addJob(analysis, opts) {
  let urls = [];
  if (analysis.kind === 'group') urls = analysis.items.map((i) => `ytsearch1:${searchQuery(i)}`);
  else if (analysis.kind === 'track') urls = [analysis.match.url];
  else if (analysis.kind === 'playlist') urls = [analysis.url];
  else urls = [opts.wholePlaylist && analysis.playlistUrl ? analysis.playlistUrl : analysis.url];

  const outDir = engine.ensureDir(opts.outDir || settings.outDir);
  const job = {
    id: uid(),
    createdAt: Date.now(),
    source: analysis.source,
    sourceLabel: analysis.sourceLabel,
    kind: analysis.kind,
    title: analysis.title,
    artist: analysis.artist || (analysis.match && analysis.match.channel) || '',
    thumb: analysis.thumb,
    url: analysis.url,
    match: analysis.match || null,
    items: analysis.items || null,
    count: analysis.count || 1,
    urls,
    wholePlaylist: !!opts.wholePlaylist,
    mode: opts.mode,
    audioFormat: opts.audioFormat,
    quality: opts.quality,
    noPlaylist: !!opts.noPlaylist,
    outDir,
    template: settings.fileTemplate,
    status: 'queued',
    phase: null,
    progress: null,
    item: null,
    files: [],
    error: null,
    startedAt: null,
    finishedAt: null,
    lastSend: 0,
    handle: null,
  };
  queue.unshift(job);
  persist();
  send('job', { ...job, handle: undefined });
  tick();
  return job;
}

function publicJob(job) {
  return { ...job, handle: undefined };
}

function tick() {
  const max = Math.max(1, Number(settings.maxConcurrent) || 2);
  while (active < max) {
    const next = queue.find((j) => j.status === 'queued');
    if (!next) break;
    startJob(next);
  }
}

function startJob(job) {
  if (!bins.ytDlp) {
    job.status = 'error';
    job.error = 'yt-dlp bulunamadı. Ayarlar sayfasından kurun.';
    send('job', publicJob(job));
    return;
  }
  active += 1;
  job.status = 'downloading';
  job.error = null;
  job.progress = null;
  job.item = null;
  job.phase = null;
  job.files = [];
  job.startedAt = Date.now();
  job.finishedAt = null;
  send('job', publicJob(job));

  job.handle = engine.runJob(
    job,
    { ytDlp: bins.ytDlp, ffmpeg: bins.ffmpeg, settings },
    (ev) => onJobEvent(job, ev),
    (res) => onJobExit(job, res),
  );
}

function onJobEvent(job, ev) {
  if (ev.type === 'progress') {
    job.progress = ev;
    if (job.phase === 'merge' || job.phase === 'post') { /* asama korunur */ }
    else job.phase = 'download';
  } else if (ev.type === 'item') {
    job.item = ev;
  } else if (ev.type === 'phase') {
    job.phase = ev.phase;
  } else if (ev.type === 'file') {
    if (ev.path && !job.files.includes(ev.path)) job.files.push(ev.path);
  } else if (ev.type === 'error') {
    job.error = ev.message;
  }
  const now = Date.now();
  if (now - job.lastSend > 120) {
    job.lastSend = now;
    send('job', publicJob(job));
  }
}

function onJobExit(job, res) {
  active = Math.max(0, active - 1);
  job.handle = null;
  job.finishedAt = Date.now();
  job.phase = null;
  job.files = res.files && res.files.length ? res.files : job.files;

  if (job.canceled) {
    job.status = 'canceled';
    job.error = null;
  } else if (res.error && job.files.length) {
    job.status = 'partial';
    job.error = res.error;
  } else if (res.error) {
    job.status = 'error';
    job.error = res.error;
  } else {
    job.status = 'done';
    job.error = null;
    if (job.progress) job.progress = { ...job.progress, pct: 100 };
  }

  if (job.status === 'done' && !job.files.length) {
    job.note = 'Aynı adlı dosya zaten vardı, yeniden yazılmadı.';
  }

  persist();
  send('job', publicJob(job));
  tick();
}

function cloneJob(j) {
  return {
    id: uid(),
    createdAt: Date.now(),
    source: j.source,
    sourceLabel: j.sourceLabel,
    kind: j.kind,
    title: j.title,
    artist: j.artist,
    thumb: j.thumb,
    url: j.url,
    match: j.match,
    items: j.items,
    count: j.count,
    urls: j.urls,
    wholePlaylist: j.wholePlaylist,
    mode: j.mode,
    audioFormat: j.audioFormat,
    quality: j.quality,
    noPlaylist: j.noPlaylist,
    outDir: j.outDir,
    template: j.template,
    status: 'queued',
    phase: null,
    progress: null,
    item: null,
    files: [],
    error: null,
    startedAt: null,
    finishedAt: null,
    lastSend: 0,
    handle: null,
  };
}

function findJob(id) {
  return queue.find((j) => j.id === id) || null;
}

const ACTIVE_STATES = new Set(['queued', 'downloading']);

/* ---------------------------------------------------------------------- ipc */

function registerIpc() {
  ipcMain.handle('state:get', () => ({
    settings,
    bins,
    queue: queue.map(publicJob),
    platform: process.platform,
  }));

  ipcMain.handle('dialog:pickFolder', async () => {
    const res = await dialog.showOpenDialog(win, {
      properties: ['openDirectory', 'createDirectory'],
      defaultPath: settings.outDir,
      title: 'İndirme klasörü',
    });
    if (res.canceled || !res.filePaths[0]) return null;
    return res.filePaths[0];
  });

  ipcMain.handle('analyze', async (_e, url) => analyzeUrl(url));

  ipcMain.handle('job:add', (_e, payload) => {
    const job = addJob(payload.analysis, payload.options || {});
    return publicJob(job);
  });

  ipcMain.handle('job:cancel', (_e, id) => {
    const job = findJob(id);
    if (!job) return null;
    if (job.status === 'queued') {
      job.status = 'canceled';
      job.finishedAt = Date.now();
      persist();
      send('job', publicJob(job));
    } else if (job.status === 'downloading' && job.handle) {
      job.canceled = true;
      job.handle.kill();
    }
    return publicJob(job);
  });

  ipcMain.handle('job:retry', (_e, id) => {
    const job = findJob(id);
    if (!job) return null;
    const copy = cloneJob(job);
    queue.unshift(copy);
    persist();
    send('job', publicJob(copy));
    tick();
    return publicJob(copy);
  });

  ipcMain.handle('job:remove', (_e, id) => {
    const job = findJob(id);
    if (!job) return false;
    if (ACTIVE_STATES.has(job.status)) return false;
    queue = queue.filter((j) => j.id !== id);
    persist();
    send('job:removed', { id });
    return true;
  });

  ipcMain.handle('job:clearHistory', () => {
    queue = queue.filter((j) => ACTIVE_STATES.has(j.status));
    persist();
    send('queue:cleared', true);
    return true;
  });

  ipcMain.handle('settings:save', (_e, patch) => {
    saveSettings(patch);
    if (patch && (patch.ytDlpPath !== undefined || patch.ffmpegPath !== undefined)) refreshBins();
    if (patch && patch.outDir) engine.ensureDir(patch.outDir);
    return settings;
  });

  ipcMain.handle('bin:install', async (_e, which) => {
    try {
      const onProgress = (p) => send('bin:progress', { which, ...p });
      let res;
      if (which === 'ffmpeg') res = await engine.installFfmpeg(onProgress);
      else res = await engine.installYtDlp(onProgress);
      await refreshBins();
      send('bin:done', { which, ok: true, version: res.version });
      return { ok: true, version: res.version };
    } catch (e) {
      send('bin:done', { which, ok: false, error: e.message });
      return { ok: false, error: e.message };
    }
  });

  ipcMain.handle('shell:reveal', (_e, p) => {
    if (!p) return false;
    if (fs.existsSync(p)) shell.showItemInFolder(p);
    else if (fs.existsSync(settings.outDir)) shell.openPath(settings.outDir);
    return true;
  });

  ipcMain.handle('shell:open', (_e, p) => {
    if (!p) return false;
    shell.openPath(p);
    return true;
  });
}

/* ------------------------------------------------------------------- pencere */

function createWindow() {
  const bg = settings.theme === 'dark' ? '#191713' : '#FBFAF7';
  win = new BrowserWindow({
    width: 1180,
    height: 800,
    minWidth: 900,
    minHeight: 620,
    backgroundColor: bg,
    title: 'Marj',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });

  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });

  app.whenReady().then(async () => {
    loadSettings();
    loadQueue();
    engine.ensureDir(settings.outDir);
    registerIpc();
    await refreshBins();
    createWindow();
    tick();
  });

  app.on('window-all-closed', () => {
    persistNow();
    app.quit();
  });

  app.on('before-quit', () => {
    for (const j of queue) if (j.handle) { j.canceled = true; j.handle.kill(); }
    persistNow();
  });
}
