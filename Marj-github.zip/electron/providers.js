'use strict';

/**
 * providers.js - link cozumleme ve Spotify meta verisi.
 * Elektron'a bagimli degildir; saf Node/HTTP kullanir.
 */

const https = require('https');
const { URL } = require('url');

const YT_HOSTS = new Set([
  'youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com',
  'youtu.be', 'www.youtu.be', 'youtube-nocookie.com', 'www.youtube-nocookie.com',
]);

const SPOTIFY_HOSTS = new Set([
  'open.spotify.com', 'www.open.spotify.com', 'spotify.link', 'www.spotify.link',
  'play.spotify.com',
]);

const SPOTIFY_TYPES = new Set(['track', 'album', 'playlist', 'episode', 'show', 'artist']);

function httpGet(rawUrl, { timeoutMs = 15000, maxRedirects = 5, headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const attempt = (u, left) => {
      let parsed;
      try { parsed = new URL(u); } catch (e) { return reject(e); }
      const req = https.get(
        parsed,
        {
          timeout: timeoutMs,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
            'Accept': '*/*',
            ...headers,
          },
        },
        (res) => {
          const status = res.statusCode || 0;
          if (status >= 300 && status < 400 && res.headers.location && left > 0) {
            res.resume();
            return attempt(new URL(res.headers.location, parsed).toString(), left - 1);
          }
          const chunks = [];
          res.on('data', (c) => chunks.push(c));
          res.on('end', () => {
            const body = Buffer.concat(chunks).toString('utf8');
            if (status >= 400) {
              const err = new Error(`HTTP ${status}`);
              err.status = status;
              err.body = body.slice(0, 300);
              return reject(err);
            }
            resolve({ status, body, url: parsed.toString(), headers: res.headers });
          });
        },
      );
      req.on('timeout', () => { req.destroy(new Error('Zaman asimi')); });
      req.on('error', reject);
    };
    attempt(rawUrl, maxRedirects);
  });
}

async function httpJson(rawUrl, opts) {
  const res = await httpGet(rawUrl, opts);
  try {
    return JSON.parse(res.body);
  } catch {
    const err = new Error('Sunucu JSON dondurmedi.');
    err.body = res.body.slice(0, 200);
    throw err;
  }
}

/** spotify.link gibi kisa linkleri gercek adresine yonlendirir. */
async function resolveRedirect(rawUrl, opts) {
  try {
    const res = await httpGet(rawUrl, { ...opts, method: 'HEAD' });
    return res.url || rawUrl;
  } catch {
    return rawUrl;
  }
}

function finalize(info) {
  if (info.source === 'spotify') {
    info.sourceLabel = 'Spotify';
    info.playlistish = ['album', 'playlist', 'show'].includes(info.type);
    info.searchable = ['track', 'episode'].includes(info.type);
    info.supported = info.type !== 'artist';
  }
  if (info.source === 'ytmusic') info.sourceLabel = 'YouTube Music';
  if (info.source === 'youtube') info.sourceLabel = 'YouTube';
  return info;
}

/**
 * Verilen metni cozumler.
 * Deger: { ok, source, sourceLabel, type, id, url, videoUrl?, playlistUrl?, playlistId?, ... }
 */
function detect(raw) {
  const text = String(raw || '').trim().replace(/^[<("'[\s]+|[>)"'\s]+$/g, '');
  if (!text) return { ok: false, reason: 'Bir link yapistirin.' };

  const uri = text.match(/^spotify[:/](track|album|playlist|episode|show|artist)[:/](\w+)$/i);
  if (uri) {
    const type = uri[1].toLowerCase();
    return finalize({
      ok: true,
      source: 'spotify',
      type,
      id: uri[2],
      url: `https://open.spotify.com/${type}/${uri[2]}`,
    });
  }

  let u;
  try {
    u = new URL(text);
  } catch {
    return {
      ok: false,
      reason: 'Metin bir URL degil. Ornek: https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    };
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') {
    return { ok: false, reason: 'Sadece http ve https linkleri desteklenir.' };
  }

  const host = u.hostname.toLowerCase();

  if (YT_HOSTS.has(host)) {
    const isMusic = host === 'music.youtube.com';
    const seg = u.pathname.split('/').filter(Boolean);
    let videoId = null;

    if (host === 'youtu.be' || host === 'www.youtu.be') {
      videoId = seg[0] || null;
    } else if (u.pathname === '/watch') {
      videoId = u.searchParams.get('v');
    } else if (['shorts', 'embed', 'live', 'v'].includes(seg[0])) {
      videoId = seg[1] || null;
    }

    const listId = u.searchParams.get('list');
    const playlistUrl = listId ? `https://www.youtube.com/playlist?list=${listId}` : null;

    if (!videoId && !playlistUrl) {
      return { ok: false, reason: 'Bu YouTube linkinde bir video veya liste bulunamadi.' };
    }

    if (!videoId) {
      return finalize({
        ok: true,
        source: 'youtube',
        type: 'playlist',
        id: listId,
        url: playlistUrl,
        playlistUrl,
        playlistId: listId,
      });
    }

    return finalize({
      ok: true,
      source: isMusic ? 'ytmusic' : 'youtube',
      type: 'video',
      id: videoId,
      url: `https://www.youtube.com/watch?v=${videoId}`,
      videoUrl: `https://www.youtube.com/watch?v=${videoId}`,
      playlistUrl,
      playlistId: listId,
      hasPlaylistChoice: Boolean(listId),
    });
  }

  if (SPOTIFY_HOSTS.has(host)) {
    if (host.includes('spotify.link')) {
      return { ok: true, source: 'spotify', type: 'shortlink', id: null, url: u.toString(), needsResolve: true };
    }
    const seg = u.pathname.split('/').filter(Boolean);
    const idx = seg.findIndex((s) => SPOTIFY_TYPES.has(s));
    if (idx === -1) {
      return {
        ok: false,
        reason: 'Spotify linki bir parcaya ait degil. Parca, album veya calma listesi linki kullanin.',
      };
    }
    const type = seg[idx];
    const id = seg[idx + 1];
    if (!id) return { ok: false, reason: 'Spotify linkinde kimlik bulunamadi.' };
    return finalize({
      ok: true,
      source: 'spotify',
      type,
      id,
      url: `https://open.spotify.com/${type}/${id}`,
    });
  }

  return {
    ok: false,
    reason: `Desteklenmeyen kaynak: ${host}. Desteklenenler: youtube.com, youtu.be, music.youtube.com, open.spotify.com`,
    host,
  };
}

function spotifyIdFromUrl(url) {
  const u = new URL(url);
  const seg = u.pathname.split('/').filter(Boolean);
  const idx = seg.findIndex((s) => SPOTIFY_TYPES.has(s));
  return idx === -1 ? null : seg[idx + 1];
}

/** Spotify oEmbed: baslik + kapak gorseli. Anahtar gerektirmez. */
async function spotifyMeta(url) {
  const data = await httpJson(
    `https://open.spotify.com/oembed?url=${encodeURIComponent(url)}`,
    { timeoutMs: 15000 },
  );
  return {
    title: data.title || '',
    thumb: data.thumbnail_url || null,
    width: data.thumbnail_width || null,
    height: data.thumbnail_height || null,
  };
}

function walkJson(node, out, depth = 0) {
  if (!node || depth > 12 || out.length > 500) return;
  if (Array.isArray(node)) {
    for (const item of node) walkJson(item, out, depth + 1);
    return;
  }
  if (typeof node !== 'object') return;

  if (Array.isArray(node.trackList)) {
    for (const t of node.trackList) {
      if (t && typeof t.uri === 'string') walkJson(t, out, depth + 1);
    }
  }

  const uri = typeof node.uri === 'string' ? node.uri : null;
  const m = uri && uri.match(/^spotify:(track|episode):(\w+)$/);
  if (m) {
    const name = node.name || node.title || '';
    let artist = '';
    if (Array.isArray(node.artists) && node.artists[0]) artist = node.artists[0].name || '';
    else if (typeof node.subtitle === 'string') artist = node.subtitle;
    const ms = typeof node.duration === 'number' ? node.duration : null;
    if (!out.some((x) => x.id === m[2])) {
      out.push({ type: m[1], id: m[2], title: name, artist, duration: ms ? Math.round(ms / 1000) : null });
    }
  }
  for (const key of Object.keys(node)) walkJson(node[key], out, depth + 1);
}

function extractJsonScripts(html) {
  const found = [];
  const re = /<script[^>]*type=["']application\/json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(html))) {
    const raw = m[1].trim();
    if (!raw || raw.length < 20) continue;
    try { found.push(JSON.parse(raw)); } catch { /* atlanir */ }
  }
  const next = html.match(/<script id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
  if (next) {
    try { found.push(JSON.parse(next[1])); } catch { /* atlanir */ }
  }
  return found;
}

/**
 * Spotify album/playlist/show icin parc listesini okur.
 * Kayit gerektirmeyen iki yol dener: gomulu sayfa JSON'u, sonra parca kimliklerinin deseni.
 * Basliklar Spotify oEmbed ile dogrulanir.
 */
async function enumerateSpotify(url, { onProgress } = {}) {
  const items = [];
  try {
    const res = await httpGet(url.replace('/open.spotify.com/', '/open.spotify.com/embed/'), {
      timeoutMs: 20000,
      headers: { Referer: url },
    });
    const html = res.body;
    for (const json of extractJsonScripts(html)) walkJson(json, items);
    if (items.length === 0) {
      const re = /spotify:(track|episode):(\w{22})/g;
      let m;
      const seen = new Set();
      while ((m = re.exec(html))) {
        if (seen.has(m[2])) continue;
        seen.add(m[2]);
        items.push({ type: m[1], id: m[2], title: '', artist: '' });
      }
    }
  } catch (e) {
    const err = new Error(`Spotify liste sayfasi okunamadi: ${e.message}`);
    err.cause = e;
    throw err;
  }

  if (items.length === 0) {
    const err = new Error(
      'Bu Spotify baglantisinda parca listesi okunamadi. Parcalari tek tek link olarak yapistirabilirsiniz.',
    );
    throw err;
  }

  const limit = 200;
  const slice = items.slice(0, limit);
  let done = 0;
  for (let i = 0; i < slice.length; i += 6) {
    const batch = slice.slice(i, i + 6);
    await Promise.all(
      batch.map(async (it) => {
        if (it.title) { done += 1; return; }
        try {
          const meta = await spotifyMeta(`https://open.spotify.com/${it.type}/${it.id}`);
          if (meta.title) it.title = meta.title;
        } catch { /* baslik bos kalir */ }
        done += 1;
        if (onProgress) onProgress(done, slice.length);
      }),
    );
  }

  return slice.map((it) => ({
    ...it,
    url: `https://open.spotify.com/${it.type}/${it.id}`,
  }));
}

/** YouTube'da bir sarki icin en iyi eslesme adayini bulur. */
async function youtubeSearch(query, { ytdlp, timeoutMs = 45000 } = {}) {
  const { analyze } = require('./engine');
  const info = await analyze({
    urls: [`ytsearch1:${query}`],
    mode: 'search',
    ytdlp,
    timeoutMs,
  });
  const entry = Array.isArray(info.entries) ? info.entries[0] : info;
  if (!entry || !entry.id) {
    const err = new Error(`"${query}" icin YouTube'da eslesme bulunamadi.`);
    throw err;
  }
  return {
    id: entry.id,
    url: `https://www.youtube.com/watch?v=${entry.id}`,
    title: entry.title || query,
    channel: entry.uploader || entry.channel || '',
    duration: entry.duration || null,
    thumb: entry.thumbnail || null,
  };
}

module.exports = {
  detect,
  httpGet,
  httpJson,
  resolveRedirect,
  spotifyMeta,
  enumerateSpotify,
  youtubeSearch,
  spotifyIdFromUrl,
};
