'use strict';

/**
 * engine.js - yt-dlp/ffmpeg kurulumu, link analizi ve indirme motoru.
 * Elektron app nesnesine sadece dizin icin bagimlidir; diger kisim saf Node'dur.
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');
const { URL } = require('url');
const { spawn, execFile } = require('child_process');
const { app } = require('electron');

const IS_WIN = process.platform === 'win32';
const YTDLP_NAME = IS_WIN ? 'yt-dlp.exe' : 'yt-dlp';
const FFMPEG_NAME = IS_WIN ? 'ffmpeg.exe' : 'ffmpeg';
const ESC = String.fromCharCode(27);
const ANSI_RE = new RegExp(ESC + '\\[[0-9;]*m', 'g');

const YTDLP_URL = IS_WIN
  ? 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe'
  : 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp';

const FFMPEG_URL = {
  win32: 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip',
  linux: 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linux64-gpl.tar.xz',
};

const MEDIA_EXT = new Set([
  '.mp3', '.m4a', '.opus', '.ogg', '.oga', '.flac', '.wav', '.aac', '.wma',
  '.mp4', '.mkv', '.webm', '.mov', '.m4v', '.avi', '.3gp', '.ts',
]);

function userDataDir() {
  try { return app.getPath('userData'); } catch { return path.join(os.homedir(), '.marj'); }
}

function binDir() {
  const d = path.join(userDataDir(), 'bin');
  try { fs.mkdirSync(d, { recursive: true }); } catch { /* yok sayilir */ }
  return d;
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/**
 * Bir arac yolunu string'e indirger. locate() sonucu {bin, source, version}
 * nesnesi de olabilir, dogrudan yol da: spawn()/execFile() her ikisini de
 * tek sekilde kabul etmeli.
 */
function binPath(v) {
  if (!v) return '';
  if (typeof v === 'string') return v;
  if (typeof v.bin === 'string') return v.bin;
  if (typeof v.path === 'string') return v.path;
  return '';
}

function which(cmd) {
  return new Promise((resolve) => {
    const probe = IS_WIN ? 'where' : 'which';
    execFile(probe, [cmd], { windowsHide: true }, (err, stdout) => {
      if (err) return resolve(null);
      const line = String(stdout).split(/\r?\n/).map((s) => s.trim()).find(Boolean);
      resolve(line || null);
    });
  });
}

function runVersion(bin, args) {
  return new Promise((resolve) => {
    execFile(bin, args, { windowsHide: true, timeout: 20000 }, (err, stdout) => {
      if (err) return resolve(null);
      const first = String(stdout).split(/\r?\n/).find((l) => l && l.trim());
      resolve(first ? first.trim() : null);
    });
  });
}

async function locateOne(custom, name, versionArgs) {
  const candidates = [];
  if (custom) candidates.push({ p: custom, source: 'ozel' });
  candidates.push({ p: path.join(binDir(), name), source: 'uygulama' });
  const onPath = await which(name.replace(/\.exe$/, ''));
  if (onPath) candidates.push({ p: onPath, source: 'sistem' });

  for (const c of candidates) {
    let exists = false;
    try { exists = fs.existsSync(c.p); } catch { exists = false; }
    if (!exists) continue;
    const version = await runVersion(c.p, versionArgs);
    if (version) return { bin: c.p, source: c.source, version };
  }
  return null;
}

/** yt-dlp ve ffmpeg konumlarini bulur (indirmez). */
async function locate({ settings = {} } = {}) {
  const ytDlp = await locateOne(settings.ytDlpPath, YTDLP_NAME, ['--version']);
  const ffmpeg = await locateOne(settings.ffmpegPath, FFMPEG_NAME, ['-version']);
  return { ytDlp, ffmpeg };
}

function downloadToFile(rawUrl, dest, onProgress) {
  return new Promise((resolve, reject) => {
    const attempt = (u, left) => {
      let parsed;
      try { parsed = new URL(u); } catch (e) { return reject(e); }
      const req = https.get(
        parsed,
        { timeout: 60000, headers: { 'User-Agent': 'Marj/1.0' } },
        (res) => {
          const status = res.statusCode || 0;
          if (status >= 300 && status < 400 && res.headers.location && left > 0) {
            res.resume();
            return attempt(new URL(res.headers.location, parsed).toString(), left - 1);
          }
          if (status !== 200) {
            res.resume();
            return reject(new Error('Indirme basarisiz: HTTP ' + status));
          }
          const total = Number(res.headers['content-length']) || 0;
          const part = dest + '.part';
          const out = fs.createWriteStream(part);
          let done = 0;
          let lastEmit = 0;
          res.on('data', (chunk) => {
            done += chunk.length;
            const now = Date.now();
            if (onProgress && (now - lastEmit > 120 || done === total)) {
              lastEmit = now;
              onProgress({ done, total });
            }
          });
          res.pipe(out);
          const fail = (e) => { try { out.destroy(); } catch { /* yoksay */ } reject(e); };
          res.on('error', fail);
          out.on('error', fail);
          out.on('finish', () => {
            out.close(() => {
              try {
                fs.rmSync(dest, { force: true });
                fs.renameSync(part, dest);
                resolve(dest);
              } catch (e) { reject(e); }
            });
          });
        },
      );
      req.on('timeout', () => req.destroy(new Error('Zaman asimi')));
      req.on('error', reject);
    };
    attempt(rawUrl, 5);
  });
}

/** yt-dlp'yi resmi yayindan indirir. */
async function installYtDlp(onProgress) {
  const dest = path.join(binDir(), YTDLP_NAME);
  await downloadToFile(YTDLP_URL, dest, onProgress);
  if (!IS_WIN) fs.chmodSync(dest, 0o755);
  const version = await runVersion(dest, ['--version']);
  if (!version) throw new Error('yt-dlp indirildi ama calistirilamadi.');
  return { bin: dest, source: 'uygulama', version };
}

function extractArchive(archive, targetDir) {
  return new Promise((resolve, reject) => {
    ensureDir(targetDir);
    if (IS_WIN) {
      const cmd = "Expand-Archive -Force -Path '" + archive + "' -DestinationPath '" + targetDir + "'";
      execFile(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', cmd],
        { windowsHide: true, timeout: 300000 },
        (err, _so, se) => {
          if (err) reject(new Error('Arşiv açılamadı: ' + ((se || '').trim().slice(0, 300) || err.message)));
          else resolve();
        },
      );
      return;
    }
    execFile('tar', ['-xf', archive, '-C', targetDir], { timeout: 300000 }, (err, _so, se) => {
      if (err) reject(new Error('Arşiv açılamadı: ' + ((se || '').trim().slice(0, 300) || err.message)));
      else resolve();
    });
  });
}

function findFile(root, name, depth = 6) {
  const stack = [root];
  let level = 0;
  while (stack.length && level < depth) {
    const next = [];
    for (const dir of stack) {
      let entries = [];
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
      for (const e of entries) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) next.push(p);
        else if (e.name === name) return p;
      }
    }
    stack.length = 0;
    stack.push(...next);
    level += 1;
  }
  return null;
}

/** FFmpeg'i resmi derlemeden indirir ve uygulama dizinine kurar. */
async function installFfmpeg(onProgress) {
  const url = FFMPEG_URL[process.platform];
  if (!url) {
    throw new Error("Bu isletim sistemi icin otomatik kurulum yok. ffmpeg'i elle kurup Ayarlar'dan gosterin.");
  }
  const stamp = Date.now().toString(36);
  const work = path.join(os.tmpdir(), 'marj-ffmpeg-' + stamp);
  const archive = path.join(work, path.basename(new URL(url).pathname));
  ensureDir(work);
  await downloadToFile(url, archive, onProgress);
  const extractDir = path.join(work, 'x');
  await extractArchive(archive, extractDir);
  const found = findFile(extractDir, FFMPEG_NAME);
  if (!found) throw new Error('Arşivde ffmpeg bulunamadı.');
  const dest = path.join(binDir(), FFMPEG_NAME);
  fs.copyFileSync(found, dest);
  if (!IS_WIN) fs.chmodSync(dest, 0o755);
  try { fs.rmSync(work, { recursive: true, force: true }); } catch { /* yoksay */ }
  const version = await runVersion(dest, ['-version']);
  if (!version) throw new Error('ffmpeg kuruldu ama calistirilamadi.');
  return { bin: dest, source: 'uygulama', version };
}

function baseArgs() {
  return [
    '--newline',
    '--no-colors',
    '--progress-template',
    'download:PROGRESS|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s',
  ];
}

function spawnEnv(extra) {
  return Object.assign({}, process.env, {
    PYTHONUTF8: '1',
    PYTHONIOENCODING: 'utf-8',
  }, extra || {});
}

function pickErrorLine(text) {
  if (!text) return '';
  const lines = String(text)
    .split(/\r?\n/)
    .map((l) => l.replace(ANSI_RE, '').trim())
    .filter(Boolean);
  const errs = lines.filter((l) => /^ERROR/i.test(l));
  const target = errs.length ? errs : lines;
  const last = target[target.length - 1] || '';
  return last.replace(/^ERROR:\s*/i, '').slice(0, 400);
}

function killTree(child) {
  if (!child || child.killed || child.exitCode !== null) return;
  try {
    if (IS_WIN) spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
    else child.kill('SIGTERM');
  } catch { try { child.kill(); } catch { /* yoksay */ } }
}

/**
 * Link/cozumleme analizi. mode: 'single' | 'playlist' | 'search'
 */
function analyze({ urls, mode = 'single', bin, ytdlp, cookies, timeoutMs = 120000 }) {
  return new Promise((resolve, reject) => {
    const exe = binPath(bin || ytdlp);
    if (!exe) return reject(new Error('yt-dlp bulunamadi.'));
    const args = ['-J'].concat(baseArgs());
    if (mode === 'single') args.push('--no-playlist');
    if (mode === 'playlist') args.push('--flat-playlist');
    if (mode === 'search') args.push('--no-playlist');
    if (cookies && cookies !== 'none') args.push('--cookies-from-browser', cookies);
    args.push(...[].concat(urls));

    let out = '';
    let err = '';
    const child = spawn(exe, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], env: spawnEnv() });
    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    const timer = setTimeout(() => {
      killTree(child);
      reject(new Error('Analiz zaman asimina ugradi. Internet baglantisini kontrol edip tekrar deneyin.'));
    }, timeoutMs);

    child.stdout.on('data', (c) => { out += c; });
    child.stderr.on('data', (c) => { err += c; });
    child.on('error', (e) => { clearTimeout(timer); reject(e); });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code !== 0) {
        const line = pickErrorLine(err) || pickErrorLine(out) || ('yt-dlp hata kodu ' + code);
        return reject(new Error(line));
      }
      try {
        resolve(JSON.parse(out));
      } catch {
        reject(new Error('yt-dlp gecerli bir veri dondurmedi.'));
      }
    });
  });
}

function buildArgs(job, cfg) {
  const { settings, ffmpeg } = cfg;
  const args = baseArgs().concat(['--no-overwrites', '-P', job.outDir]);
  args.push('-o', job.template || settings.fileTemplate || '%(title)s.%(ext)s');
  if (settings.cookies && settings.cookies !== 'none') args.push('--cookies-from-browser', settings.cookies);

  if (job.mode === 'audio') {
    if (ffmpeg && job.audioFormat && job.audioFormat !== 'source') {
      args.push('-x', '--audio-format', job.audioFormat);
      if (job.audioFormat === 'mp3') args.push('--audio-quality', '0');
      if (settings.embedMeta) args.push('--embed-metadata', '--embed-thumbnail');
    } else {
      args.push('-f', 'bestaudio/best');
    }
  } else {
    const h = job.quality || settings.videoQuality || '1080';
    if (ffmpeg) {
      args.push('-f', 'bv*[height<=' + h + ']+ba/b[height<=' + h + ']/b', '--merge-output-format', 'mp4');
    } else {
      args.push('-f', 'b[height<=' + h + ']/b');
    }
  }

  if (job.noPlaylist) args.push('--no-playlist');
  args.push(...job.urls);
  return args;
}

function snapshot(dir) {
  try { return new Set(fs.readdirSync(dir)); } catch { return new Set(); }
}

function diffFiles(before, dir, since) {
  let names = [];
  try { names = fs.readdirSync(dir); } catch { return []; }
  const out = [];
  for (const n of names) {
    if (before.has(n)) continue;
    if (/\.part$|\.ytdl$|\.temp$|\.json$/i.test(n)) continue;
    if (!MEDIA_EXT.has(path.extname(n).toLowerCase())) continue;
    const full = path.join(dir, n);
    try {
      const st = fs.statSync(full);
      if (!st.isFile()) continue;
      if (since && st.mtimeMs < since - 3000) continue;
      out.push(full);
    } catch { /* atlanir */ }
  }
  return out;
}

/**
 * Indirme isini calistirir.
 * onEvent: {type:'progress'|'item'|'phase'|'file'|'log'|'error', ...}
 * onExit:  ({code, error, files}) => {}
 */
function runJob(job, cfg, onEvent, onExit) {
  const args = buildArgs(job, cfg);
  const startedAt = Date.now();
  const before = snapshot(job.outDir);
  const seenFiles = new Set();
  let stderrTail = '';
  let child = null;

  try {
    const exe = binPath(cfg.ytDlp);
    if (!exe) throw new Error('yt-dlp bulunamadi. Ayarlar sayfasindan kurun.');
    child = spawn(exe, args, {
      cwd: job.outDir,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: spawnEnv(),
    });
  } catch (e) {
    onExit({ code: -1, error: e.message, files: [] });
    return { kill() {} };
  }

  let buffer = '';
  const handleLine = (rawLine) => {
    const line = String(rawLine).replace(ANSI_RE, '');
    if (!line.trim()) return;

    if (line.indexOf('PROGRESS|') === 0) {
      const parts = line.split('|');
      const num = (v) => {
        if (!v || v === 'NA' || v === 'None') return null;
        const f = Number(v);
        return Number.isFinite(f) ? f : null;
      };
      const bytes = num(parts[1]);
      const total = num(parts[2]) || num(parts[3]);
      const pct = total ? Math.min(100, (bytes / total) * 100) : null;
      onEvent({ type: 'progress', pct, bytes, total, speed: num(parts[4]), eta: num(parts[5]) });
      return;
    }

    let m = line.match(/\[download\] Downloading item (\d+) of (\d+)/);
    if (m) {
      onEvent({ type: 'item', index: Number(m[1]), count: Number(m[2]) });
      return;
    }
    m = line.match(/\] Destination:\s*(.+)$/) || line.match(/\[download\] Destination:\s*(.+)$/);
    if (m) {
      const p = m[1].trim();
      seenFiles.add(p);
      onEvent({ type: 'file', path: p });
      // Dönüştürme satırları ([ExtractAudio] Destination: ...) hem dosya hem asamadir.
      if (/^\[(ExtractAudio|VideoConvertor)\]/.test(line)) onEvent({ type: 'phase', phase: 'post' });
      return;
    }
    // Ayni adli dosya zaten varsa yt-dlp indirmeyi atlar ve Destination yazmaz.
    // Yine de kullanici dosyayi gorebilsin diye yol buradan cozumlenir.
    m = line.match(/^(?:\[download\]\s*)?(.+) has already been downloaded$/);
    if (m) {
      const p = m[1].trim();
      let ok = false;
      try { ok = fs.existsSync(p); } catch { ok = false; }
      if (ok && !seenFiles.has(p)) {
        seenFiles.add(p);
        onEvent({ type: 'file', path: p });
      }
      return;
    }
    m = line.match(/Merging formats into\s+"?([^"]+)"?\s*$/);
    if (m) {
      const p = m[1].trim();
      seenFiles.add(p);
      onEvent({ type: 'file', path: p });
      onEvent({ type: 'phase', phase: 'merge' });
      return;
    }
    if (/^\[(Metadata|EmbedThumbnail|EmbedMetadata)\]/.test(line)) {
      onEvent({ type: 'phase', phase: 'post' });
      return;
    }
    if (/^ERROR:/i.test(line)) {
      onEvent({ type: 'error', message: line.replace(/^ERROR:\s*/i, '') });
      return;
    }
    onEvent({ type: 'log', line });
  };

  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    buffer += chunk;
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const l of parts) handleLine(l);
  });

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    stderrTail = (stderrTail + String(chunk)).slice(-4000);
    const lines = String(chunk).split(/\r?\n/);
    for (const l of lines) if (l.trim()) onEvent({ type: 'log', line: l });
  });

  child.on('error', (e) => onExit({ code: -1, error: e.message, files: [] }));

  child.on('close', (code) => {
    if (buffer.trim()) handleLine(buffer);
    const created = diffFiles(before, job.outDir, startedAt);
    // Dönüştürmede silinen ara dosyalar (ör. mp3 dönüşümünde kaynak .webm)
    // listede kalmasın: yalnizca hala diskte olanlar raporlanir.
    const alive = (p) => { try { return fs.existsSync(p); } catch { return false; } };
    const files = [...new Set([...seenFiles, ...created])].filter(alive);
    if (code === 0) {
      onExit({ code, error: null, files });
    } else {
      const msg = pickErrorLine(stderrTail) || ('yt-dlp hata kodu ' + code);
      onExit({ code, error: code === null ? 'İndirme iptal edildi.' : msg, files });
    }
  });

  return {
    kill() { killTree(child); },
  };
}

module.exports = {
  locate,
  installYtDlp,
  installFfmpeg,
  analyze,
  runJob,
  snapshot,
  diffFiles,
  ensureDir,
  MEDIA_EXT,
  YTDLP_NAME,
  FFMPEG_NAME,
  binDir,
};
