'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const CHANNELS = ['job', 'job:removed', 'queue:cleared', 'settings', 'bins', 'bin:progress', 'bin:done'];

contextBridge.exposeInMainWorld('marj', {
  state: () => ipcRenderer.invoke('state:get'),
  analyze: (url) => ipcRenderer.invoke('analyze', url),
  addJob: (analysis, options) => ipcRenderer.invoke('job:add', { analysis, options }),
  cancel: (id) => ipcRenderer.invoke('job:cancel', id),
  retry: (id) => ipcRenderer.invoke('job:retry', id),
  remove: (id) => ipcRenderer.invoke('job:remove', id),
  clearHistory: () => ipcRenderer.invoke('job:clearHistory'),
  saveSettings: (patch) => ipcRenderer.invoke('settings:save', patch),
  pickFolder: () => ipcRenderer.invoke('dialog:pickFolder'),
  installBin: (which) => ipcRenderer.invoke('bin:install', which),
  reveal: (p) => ipcRenderer.invoke('shell:reveal', p),
  openPath: (p) => ipcRenderer.invoke('shell:open', p),
  on: (channel, cb) => {
    if (!CHANNELS.includes(channel)) return () => {};
    const handler = (_event, data) => cb(data);
    ipcRenderer.on(channel, handler);
    return () => ipcRenderer.off(channel, handler);
  },
});
