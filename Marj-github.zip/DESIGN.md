# Marj - Tasarım Yönü (DESIGN.md)

Bu dosya ürünün **görsel yönünün** kaynağıdır. antislop (R-37) kuralı gereği arayüz
bu yön olmadan üretilmez; üretim sırasında aşağıdkiler uygulanır.

## Kimlik

- **Ürün**: Marj - YouTube / YouTube Music / Spotify linklerinden ses ve video indirme aracı.
- **Kişilik**:Editoryal, sakin, güvenilir. Bir gazete dizgisi veya prova okuyucusu gibi:
  gereksiz süs yok, kenar boşluğu (marj) ve cetvel çizgileri kimliktir.
- **Motif (identity motif)**: **Marj çizgisi**. Sol kenarda dikey kıl-cetvel, kuyruk
  satırlarında matbu folyo numaraları (01, 02, 03) ve durum işaretleri kırmızı prova
  kalemi gibi. Motif her ekranda tekrar eder, dekor olarak değil, bilgi taşıyarak.
- **Simgeler**: Kelime markası "MARJ" metin olarak (font-logo). Üretilmiş bir logo yok (R-23).

## Design Read

> Okuma: günlük tekrarlı kullanılan bir masaüstü medya indirme aracı, açık editoryal
> (kağıt-mürekkep) dilde, dial ENERGY 2 / RHYTHM 2 / MOTION 1.

## Üç kadran

| Kadran | Değer | Gerekçe |
|---|---|---|
| ENERGY | 2 (dengeli) | Araç amaçlı; boş sayfa kadar sakin, bir kayıt uygulaması kadar da var. |
| RHYTHM | 2 (tutarlı + birkaç kırılım) | Kuyruk satırları tek düzen; analiz paneli ve ayarlar farklı kompozisyon kullanır. |
| MOTION | 1 (yalnızca hover/geçiş) | Tekrarlı kullanım; hareket işi geciktirmemeli. Dekoratif sonsuz döngü animasyonu yok (R-19); belirsiz süreli tek işin göstergesi (`.spinner`) döner ve `prefers-reduced-motion` ile durur. |

## Palet (R-29: 2-3 çekirdek + 1 aksan)

**Açık baskı (varsayılan)**

| Rol | Değer | Gerekçe / kontrast |
|---|---|---|
| Kağıt (zemin) | `#FBFAF7` | Sıcak beyaz; gazete kağıdı hissi, saf beyazın ekran parlaması yok. |
| Mürekkep (metin) | `#1A1917` | Kağıt üzerinde ~17:1 (R-25 için fazlasıyla yeterli). |
| İkincil metin | `#5C574E` | Kağıt üzerinde ~6.5:1, AA'yı geçer. |
| Kıl-cetvel | `#DED8CC` | Ayırıcılar; metin değil, sadece çizgi (kontrast şartı yok). |
| Prova kırmızısı (aksan) | `#C63B1C` | Kağıt üzerinde ~5.0:1; kenar boşluğu işaretleri, hata durumu, ana eylem. |

**Gece baskısı (koyu tema)**

| Rol | Değer | Kontrast |
|---|---|---|
| Kağıt | `#191713` | Sıcak koyu; mürekkep `#F2EEE4` ile ~15:1 |
| İkincil metin | `#A39C8E` | ~6.3:1 |
| Aksan | `#F0563A` | ~5.0:1 |

Tek aksan = prova kırmızısı. Aksan her yerde kullanılmaz; ana eylem, aktif durum ve
hata işaretinde görünür (bir aksan ilkesi, R-01 / R-13 doz sınırı).

## Tipografi (R-06)

- **Başlık / kelime markası**: `Charter, "Bitstream Charter", "Sitka Text", Cambria, Georgia, "Liberation Serif", serif`.
  Gerekçe: editoryal serif kimliğin taşıyıcısı; Windows (Charter/Sitka/Cambria), macOS
  (Iowan/Georgia), Linux (Liberation Serif) için hazır yedek zinciri, font indirmesi yok.
- **Arayüz**: `system-ui, "Segoe UI", "Noto Sans", Roboto, sans-serif`.
  Gerekçe: platformun kendi yazı tipi; işletim sistemiyle uyumlu, indirme yok, iyi hinting.
- Büyük monospace başlık yok, geniş harf aralıklı büyük harf etiket yok (R-06).
- Sayılar (süre, boyut, ilerleme) `tabular-nums` ile hizalanır: hizalama bilgi taşır.

## Izgara ve boşluk

- Ölçek: 4 / 8 / 12 / 16 / 24 / 32 / 48 px.
- Sol marj rayı 204 px (kelime markası + gerçek gezinme), içerik alanı esnek.
- Yalnızca gerektiği yerde gölge (R-12): modal ve düşen menü. Kartlar düz durur.

## Yasaklar (bilinçli)

Mavi-mor gradyan, cam efekti, her yerde parlama, bento ızgara, sahte terminal,
dekoratif emoji, "Beta/Yeni" kapsül rozetleri, üç sütunlu fiyat tablosu, ölü buton,
kaynağı olmayan istatistik, jenerik SSS. Bunlar bu üründe hiçbir yerde geçmez.

## Durum ve erişilebilirlik

- Her veri gösteren görünümde üç durum: **boş**, **yükleniyor**, **hata** (R-27).
- Hata durumu nedeni ve sonraki adımı yazar; "Bir şeyler ters gitti" gibi muğlak metin yok.
- Klavye: Tab sırası görsel sıraya uyar, Enter gönderir, Escape kapatır, odak halkası
  görünür (R-32). Hiçbir `outline: none` yok.
- Her iki temada de aynı bileşenler doğrulanır (R-34).

## Yüzey ve etkileşim (R-31 gerekçeleri)

- **Odak halkası aksanı**: giriş alanına odak gelince `--accent` halkası tek
  odak anını işaretler; aksanı her yerde değil, dikkat gereken tek anda kullanmak
  için.
- **Birincil buton yükseliyor**: `.btn-solid` ince gölge taşır; sayfada
  yükseltilen tek eleman, atılacak tek eylem olsun diye (R-12 doz: 1 öğe).
- **Pasif solid buton nötrleşir**: soluk aksan yerine kağıt tonu; pasiflik
  rengin sürmediği bir durum olsun diye.
- **Segment kutusu tonlu**: Ses/Video seçicisinin boş alanı `paper-3`;
  seçili zemin ayrışsın, kutu kalinlaşmasın diye.
- **Boş durumda kısa aksan çizgisi**: marj çizgisi motifinin küçük hali;
  boş ekran boş kalmasın ama süs de eklenmesin diye.
- **Satır hover zemini**: kuyruk ve geçmiş satırları tıklanabilir bolge
  (dosya, iptal, tekrar) olduğu için dokunuşa yanıt verir.
- **Kaydırma çubuğu kağıt tonunda**: dikey liste yoğunluğu var; çubuk
  sayfaya yapışsın, ayrı bir katman gibi görünmesin diye.
- **Geçişler 0.12s**: MOTION 1 kadranı; hareket işi geciktirmemeli.
