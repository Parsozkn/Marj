# AGENTS.md

Bu depoda çalışmadan önce `antislop` ve `antislop-ui` skill'lerini yükle
(core filter her zaman).

## Komutlar

- `npm start` - uygulamayı geliştirme modunda başlat
- `npm run test:ui` - Playwright ile gerçek arayüz testi; çıktı:
  `screenshots/*.png` + `screenshots/report.json`
- `npm run dist:win` - Windows paketleri (nsis + portable)
- `npm run dist:linux` - Linux hedefleri (yalnızca Linux makinede derlenir)
- `npm run icon` - `build/icon.png` üretir (512x512)

Windows'ta `npm.ps1` execution policy ile engellidir; `npm.cmd` kullan ve
Node'u `PATH`'e ekle.

## Kurallar

- Framework yok, bundler yok: `renderer/` saf HTML/CSS/JS, `electron/` saf Node.
  Yeni bağımlılık eklemek için gerekçe gerekir (DESIGN.md R-31).
- UI metninde em dash (`—`) yasak; Türkçe arayüz metni Türkçe yazılır.
- Her görünümde boş, yükleniyor ve hata durumu tanımlıdır; ölü kontrol
  (etkisiz buton) bırakılmaz.
- Tasarım kararları `DESIGN.md` ile uyumlu olmalı: palet, tipografi, kadran
  değerleri (ENERGY 2 / RHYTHM 2 / MOTION 1), marj çizgisi motifi.
- Kodu değiştirdikten sonra `npm run test:ui` çalıştır ve sonucu raporla;
  ekran görüntülerini okuyup görsel regresyonu kontrol et.
- Teslim öncesi antislop Delivery Gate'i çalıştır (PASS/FAIL raporu).
