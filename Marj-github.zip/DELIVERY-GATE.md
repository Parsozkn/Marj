# Marj - antislop Delivery Gate

Tarih: 2026-09-26
Doğrulama: `npm run test:ui` → 49/49 PASS, 0 SKIP, 0 konsol hatası
(`screenshots/report.json`, `screenshots/uitest-run.log`)
Stil kanıtı: `node scripts/stylecheck.mjs` (hesaplanmış değerlerle modernizasyon doğrulaması)

## PASS

| Kural | Kanıt |
| --- | --- |
| Em dash yok (R-02) | `renderer/`, `electron/`, `scripts/`, `README.md` taraması: 0 eşleşme. Tek geçiş AGENTS.md'deki kural metni. |
| Boş durum (R-27) | `#queueEmpty`, `#historyEmpty`; test: "kuyruk bos durumu gorunur", "gecmis bos durumu gorunur". Durum metni ne yapacağını söylüyor. |
| Yükleniyor durumu (R-27) | `#analyzeLoading` + `.spinner`; test: "yukleniyor durumu gosterilir" (tıklamadan önce kurulan MutationObserver ile yarışsız). |
| Hata durumu (R-27) | `#analyzeError` + neden + "Tekrar dene"; test: "gecersiz linkte hata durumu cikiyor", "desteklenmeyen kaynak uyariliyor". |
| Klavye odak halkası (R-32) | Test: "klavye oda gorunur halka birakir" (14 sekme adımı, `:focus-visible` + outline). Giriş odak halkası aksan: `rgba(198,59,28,.16) 0 0 0 3px`. |
| Ölü kontrol yok (R-26) | Test: kurulum sonrası buton pasifleşir, iptal `canceled` (2 kez), tekrar yeni iş başlatıyor, geçmiş temizleme boş dönüyor, Spotify liste işi gerçekten 50 URL olarak kuyruğa giriyor. |
| Kontrast AA (R-25) | Açık: metin 16.83, ikincil 6.87, buton 4.98, aksan metin 4.98. Koyu: metin 15.45, ikincil 6.57, buton 5.20, aksan metin 4.83. Hepsi ≥ 4.5. |
| Konsol hatası yok (R-35) | Test: console + pageerror filtresi, 0 kayıt. |
| Yatay taşma yok (R-03) | 430px: scroll 403 ≤ inner 414. 1164px: scroll 1153 ≤ inner 1164. |
| İki tema çalışır (R-34) | Test: koyu/tema geçişleri + kontrast ölçümü her iki temada. |
| Tasarım yönü (R-37) | `DESIGN.md` mevcut: palet kağıt-mürekkep + tek aksan, serif display zinciri, marj çizgisi motifi, kadran ENERGY 2 / RHYTHM 2 / MOTION 1. |
| Karar gerekçeleri (R-31) | `DESIGN.md` "Yüzey ve etkileşim" bölümü: odak halkası, buton yükselişi, segment tonu, boş durum çizgisi, satır hover, scrollbar, 0.12s geçiş. |
| Bağımlılık (R-31 / AGENTS R-31) | Üretim bağımlılığı yok; devDependencies: electron, electron-builder, playwright, pngjs. |
| Modernizasyon kanıtı | `stylecheck.mjs`: boş durum çizgisi 36x3px `rgb(198,59,28)`; birincil buton gölgesi `0 1px 2px rgba(0,0,0,.18), 0 4px 12px -4px rgba(0,0,0,.35)`; segment zemini `rgb(234,229,219)`. |
| Test izolasyonu | `MARJ_TEST=1` geçici profil; indirme klasörü her koşuda boşaltılır; ayarlar geri alınır; kalan süreçler temizlenir. |
| Paketleme (Windows) | `dist/Marj-Setup-1.0.0-x64.exe` (77.1 MB), `dist/Marj-Portable-1.0.0-x64.exe` (76.9 MB); ad çakışması düzeltildi. |
| README dürüstlüğü | Olmayan özellikler yok (dil seçeneği, çift tıklama çıkarıldı); uydurma repo URL'si yok; uydurma istatistik yok. |

## NOT (bilinçli kabul)

| Konu | Durum |
| --- | --- |
| YouTube başarılı çoklu liste indirmesi | Test `&list=RDjNQXAC9IVRw` kullanıyor; YouTube bu karışım listesini "unviewable" döndürüyor. Seçenek görünüp gerçek tepki verdiği doğrulandı (hata durumu). Çoklu indirme Spotify tarafında karşılanıyor (50 URL, test edildi). |
| Ekran görüntüsü okuma aracı | `read` aracı PNG'yi görselle eşleştirmedi; dosya bütünlüğü boyut/hash ile, içeriğe ait görsel unsurlar `browser.preview` ile, stil unsurları `stylecheck.mjs` ile doğrulandı. |
| Linux paketleri | `.deb`/pacman bu (Windows) makinede derlenemedi; hedefler, `PKGBUILD` ve `build-deb.sh` yazıldı, Linux dışı makinede net hata veriyor. README bunu açıkça yazıyor. |
| Screenshot yarışı | Bir koşuda `10-spotify-onizleme.png` 15sn'de alınamadı, otomatik tekrar ile alındı; test düşmedi (araç, assertion değil). |

## Sonuç

**PASS**: 16 kural PASS, 4 NOT (hiçbiri gizli kusur, gerekçesiyle yukarıda).
