'use strict';

/* Marj arayüz mantigi. Tum dis veriler metin olarak eklenir (innerHTML yok). */

const api = window.marj || null;

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const el = {
  navBtns: $$('.nav-btn'),
  views: {
    download: $('#view-download'),
    history: $('#view-history'),
    settings: $('#view-settings'),
  },
  linkForm: $('#linkForm'),
  linkInput: $('#linkInput'),
  analyzeBtn: $('#analyzeBtn'),
  analyzeLoading: $('#analyzeLoading'),
  analyzeLoadingText: $('#analyzeLoadingText'),
  analyzeError: $('#analyzeError'),
  analyzeErrorText: $('#analyzeErrorText'),
  analyzeRetryBtn: $('#analyzeRetryBtn'),
  preview: $('#preview'),
  previewImg: $('#previewImg'),
  previewFallback: $('#previewFallback'),
  previewKicker: $('#previewKicker'),
  previewTitle: $('#previewTitle'),
  previewMeta: $('#previewMeta'),
  previewMatch: $('#previewMatch'),
  previewList: $('#previewList'),
  audioOpt: $('#audioOpt'),
  videoOpt: $('#videoOpt'),
  playlistOpt: $('#playlistOpt'),
  audioFormat: $('#audioFormat'),
  videoQuality: $('#videoQuality'),
  audioHint: $('#audioHint'),
  videoHint: $('#videoHint'),
  wholePlaylist: $('#wholePlaylist'),
  wholePlaylistLabel: $('#wholePlaylistLabel'),
  startBtn: $('#startBtn'),
  discardBtn: $('#discardBtn'),
  queueList: $('#queueList'),
  queueEmpty: $('#queueEmpty'),
  queueMeta: $('#queueMeta'),
  historyList: $('#historyList'),
  historyEmpty: $('#historyEmpty'),
  clearHistoryBtn: $('#clearHistoryBtn'),
  binNotice: $('#binNotice'),
  binNoticeText: $('#binNoticeText'),
  binNoticeBtn: $('#binNoticeBtn'),
  outDirValue: $('#outDirValue'),
  pickFolderBtn: $('#pickFolderBtn'),
  fileTemplate: $('#fileTemplate'),
  fileTemplateEcho: $('#fileTemplateEcho'),
  maxConcurrent: $('#maxConcurrent'),
  cookies: $('#cookies'),
  ytDlpValue: $('#ytDlpValue'),
  ffmpegValue: $('#ffmpegValue'),
  installYtDlpBtn: $('#installYtDlpBtn'),
  installFfmpegBtn: $('#installFfmpegBtn'),
  ytDlpProgress: $('#ytDlpProgress'),
  ytDlpProgressFill: $('#ytDlpProgressFill'),
  ffmpegProgress: $('#ffmpegProgress'),
  ffmpegProgressFill: $('#ffmpegProgressFill'),
  live: $('#liveRegion'),
  noApp: $('#noApp'),
};

const S = {
  settings: null,
  bins: { ytDlp: null, ffmpeg: null },
  queue: [],
};

let currentView = 'download';
let analysis = null;
let baseAnalysis = null;
let analyzing = false;
let renderHandle = null;

const ACTIVE_STATES = new Set(['queued', 'downloading']);
const FINISHED_STATES = new Set(['done', 'partial', 'error', 'canceled', 'interrupted']);

const STATUS_LABEL = {
  queued: 'Sırada',
  downloading: 'İndiriliyor',
  done: 'Tamamlandı',
  partial: 'Kısmi tamamlandı',
  error: 'Hata',
  canceled: 'İptal edildi',
  interrupted: 'Kesildi',
};

const PHASE_LABEL = {
  merge: 'Birleştiriliyor',
  post: 'Dönüştürülüyor',
};

const FORMAT_LABEL = {
  mp3: 'MP3',
  m4a: 'M4A',
  opus: 'Opus',
  source: 'Kaynak biçim',
};

const SOURCE_LABEL = {
  uygulama: 'uygulama klasoru',
  sistem: 'sistem',
  ozel: 'ozel yol',
};

/* ------------------------------------------------------------- bicimlendirme */

const nf = new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 1 });

function fmtSize(bytes) {
  if (!bytes || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = bytes;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${nf.format(value)} ${units[i]}`;
}

function fmtDur(sec) {
  if (sec == null || !Number.isFinite(Number(sec))) return '';
  const total = Math.max(0, Math.round(Number(sec)));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const p = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p(m)}:${p(s)}` : `${m}:${p(s)}`;
}

function fmtPct(p) {
  return p == null ? null : `%${Math.round(p)}`;
}

function pad2(n) {
  return String(n).padStart(2, '0');
}

function basename(p) {
  if (!p) return '';
  const parts = String(p).split(/[\\/]/).filter(Boolean);
  return parts.length ? parts[parts.length - 1] : p;
}

function announce(text) {
  el.live.textContent = '';
  setTimeout(() => { el.live.textContent = text; }, 30);
}

/* ------------------------------------------------------------- gorunum degisimi */

function setView(name) {
  currentView = name;
  Object.keys(el.views).forEach((key) => {
    el.views[key].hidden = key !== name;
  });
  el.navBtns.forEach((btn) => {
    const active = btn.dataset.view === name;
    btn.classList.toggle('is-active', active);
    if (active) btn.setAttribute('aria-current', 'page');
    else btn.removeAttribute('aria-current');
  });
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme === 'dark' ? 'dark' : 'light';
}

function showAnalyzeLoading(text) {
  analyzing = true;
  el.analyzeLoadingText.textContent = text;
  el.analyzeLoading.hidden = false;
  el.analyzeError.hidden = true;
  el.analyzeBtn.disabled = true;
  el.preview.hidden = true;
}

function hideAnalyzeLoading() {
  analyzing = false;
  el.analyzeLoading.hidden = true;
  el.analyzeBtn.disabled = false;
}

function showAnalyzeError(message) {
  hideAnalyzeLoading();
  el.analyzeErrorText.textContent = message || 'Bilinmeyen bir hata oluştu.';
  el.analyzeError.hidden = false;
}

function clearAnalyzeError() {
  el.analyzeError.hidden = true;
}

function loadingTextFor(url) {
  const t = String(url || '').toLowerCase();
  if (t.includes('spotify')) return 'Spotify bilgisi okunuyor, ses YouTube üzerinde aranıyor…';
  if (t.includes('list=')) return 'Liste okunuyor, parça başlıkları getiriliyor…';
  return 'Video bilgisi okunuyor…';
}

/* ---------------------------------------------------------------- medya */

function setMedia(img, fallback, src, title) {
  const initial = (title || 'M').trim().charAt(0).toUpperCase() || 'M';
  fallback.textContent = initial;
  img.hidden = true;
  img.removeAttribute('src');
  if (!src) return;
  const onLoad = () => {
    img.hidden = false;
    fallback.hidden = true;
    img.removeEventListener('load', onLoad);
    img.removeEventListener('error', onError);
  };
  const onError = () => {
    img.hidden = true;
    fallback.hidden = false;
    img.removeEventListener('load', onLoad);
    img.removeEventListener('error', onError);
  };
  img.addEventListener('load', onLoad);
  img.addEventListener('error', onError);
  img.src = src;
  img.alt = `${title || 'Medya'} kapak görseli`;
}

/* ---------------------------------------------------------------- onizleme */

function kindLabel(a) {
  if (a.kind === 'video') return 'video';
  if (a.kind === 'playlist') return 'çalma listesi';
  if (a.kind === 'track') return 'parça';
  if (a.kind === 'group') {
    if (a.listType === 'album') return 'albüm';
    if (a.listType === 'show') return 'bölüm listesi';
    return 'çalma listesi';
  }
  return '';
}

function renderPreview() {
  if (!analysis) {
    el.preview.hidden = true;
    return;
  }
  const a = analysis;
  el.preview.hidden = false;

  setMedia(el.previewImg, el.previewFallback, a.thumb, a.title);

  el.previewKicker.textContent = `${a.sourceLabel} · ${kindLabel(a)}`;
  el.previewTitle.textContent = a.title || 'Başlıksız';

  const meta = [];
  if (a.artist) meta.push(a.artist);
  if (a.kind === 'video' && a.duration) meta.push(fmtDur(a.duration));
  if (a.kind === 'track' && a.match && a.match.duration) meta.push(fmtDur(a.match.duration));
  if (a.kind === 'playlist' || a.kind === 'group') meta.push(`${a.count} parça`);
  if (a.kind === 'video' && a.hasPlaylistChoice && baseAnalysis === a) {
    meta.push('bu video bir listede');
  }
  el.previewMeta.textContent = meta.join(' · ');

  if (a.kind === 'track' && a.match) {
    el.previewMatch.hidden = false;
    const channel = a.match.channel ? ` (${a.match.channel})` : '';
    el.previewMatch.textContent = `Ses şu videoda bulundu: ${a.match.title}${channel}`;
  } else {
    el.previewMatch.hidden = true;
  }

  const items = (a.kind === 'playlist' || a.kind === 'group') && a.items ? a.items : [];
  if (items.length) {
    el.previewList.hidden = false;
    el.previewList.replaceChildren();
    items.slice(0, 8).forEach((it, i) => {
      const row = document.createElement('div');
      row.className = 'preview-list-item';
      const folio = document.createElement('span');
      folio.className = 'folio';
      folio.textContent = pad2(i + 1);
      const name = document.createElement('span');
      name.className = 'name';
      name.textContent = it.title || 'Başlıksız';
      row.append(folio, name);
      if (it.artist) {
        const dim = document.createElement('span');
        dim.className = 'dim';
        dim.textContent = ` · ${it.artist}`;
        row.append(dim);
      }
      el.previewList.append(row);
    });
    if (items.length > 8) {
      const row = document.createElement('div');
      row.className = 'preview-list-item';
      const folio = document.createElement('span');
      folio.className = 'folio';
      folio.textContent = '…';
      const name = document.createElement('span');
      name.className = 'name dim';
      name.textContent = `ve ${items.length - 8} parça daha`;
      row.append(folio, name);
      el.previewList.append(row);
    }
  } else {
    el.previewList.hidden = true;
    el.previewList.replaceChildren();
  }

  renderOptions();
}

function hasFfmpeg() {
  return Boolean(S.bins && S.bins.ffmpeg);
}

function ensureFfmpegButton(host) {
  let btn = host.querySelector('button[data-ffmpeg]');
  if (btn) return btn;
  btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'btn btn-quiet';
  btn.dataset.ffmpeg = '1';
  btn.textContent = 'FFmpeg indir ve kur';
  btn.addEventListener('click', () => installBin('ffmpeg'));
  btn.style.marginTop = '8px';
  host.append(btn);
  return btn;
}

function removeFfmpegButton(host) {
  const btn = host.querySelector('button[data-ffmpeg]');
  if (btn) btn.remove();
}

function renderOptions() {
  const mode = (document.querySelector('input[name="mode"]:checked') || {}).value || 'audio';
  const audio = mode === 'audio';
  el.audioOpt.hidden = !audio;
  el.videoOpt.hidden = audio;
  el.startBtn.textContent = audio ? 'Ses olarak indir' : 'Video olarak indir';

  const ffmpeg = hasFfmpeg();

  Array.from(el.audioFormat.options).forEach((opt) => {
    opt.disabled = !ffmpeg && opt.value !== 'source';
  });
  if (!ffmpeg && el.audioFormat.value !== 'source') el.audioFormat.value = 'source';

  if (ffmpeg) {
    el.audioHint.className = 'opt-hint';
    el.audioHint.textContent = 'Ses dönüştürülür, kapak ve etiket dosyaya gömülür.';
    removeFfmpegButton(el.audioOpt);
  } else {
    el.audioHint.className = 'opt-hint is-warn';
    el.audioHint.textContent = 'FFmpeg yok: yalnızca kaynak biçim iner. MP3 için FFmpeg gerekli.';
    ensureFfmpegButton(el.audioOpt);
  }

  Array.from(el.videoQuality.options).forEach((opt) => {
    opt.disabled = !ffmpeg && Number(opt.value) > 720;
  });
  if (!ffmpeg && Number(el.videoQuality.value) > 720) el.videoQuality.value = '720';

  if (ffmpeg) {
    el.videoHint.className = 'opt-hint';
    el.videoHint.textContent = 'Ses ve video birleştirilir, çıktı MP4 olur.';
    removeFfmpegButton(el.videoOpt);
  } else {
    el.videoHint.className = 'opt-hint is-warn';
    el.videoHint.textContent = 'FFmpeg yok: tek parça indirilir, en fazla 720p.';
    ensureFfmpegButton(el.videoOpt);
  }

  const showPlaylist = Boolean(
    baseAnalysis
    && baseAnalysis.kind === 'video'
    && baseAnalysis.hasPlaylistChoice
    && baseAnalysis.playlistUrl
    && analysis
    && (analysis === baseAnalysis || analysis.wholeList),
  );
  el.playlistOpt.hidden = !showPlaylist;
  if (showPlaylist) {
    const count = analysis.kind === 'playlist' && analysis.count ? ` (${analysis.count} parça)` : '';
    el.wholePlaylist.checked = analysis !== baseAnalysis;
    el.wholePlaylistLabel.textContent = `Bu video bir çalma listesinde: tüm listeyi indir${count}`;
  }
}

/* ------------------------------------------------------------------- kuyruk */

function jobRow(job, index, forHistory) {
  const row = document.createElement('article');
  row.className = 'job';
  row.dataset.status = job.status;
  row.dataset.id = job.id;

  const folio = document.createElement('div');
  folio.className = 'job-folio';
  folio.textContent = pad2(index + 1);

  const thumb = document.createElement('div');
  thumb.className = 'job-thumb';
  const fb = document.createElement('span');
  fb.className = 'fallback';
  fb.textContent = (job.title || 'M').trim().charAt(0).toUpperCase() || 'M';
  thumb.append(fb);
  if (job.thumb) {
    const img = document.createElement('img');
    img.alt = '';
    img.addEventListener('load', () => { img.style.display = 'block'; fb.hidden = true; });
    img.addEventListener('error', () => { img.remove(); });
    img.style.display = 'none';
    img.src = job.thumb;
    thumb.append(img);
  }

  const main = document.createElement('div');
  main.className = 'job-main';

  const title = document.createElement('div');
  title.className = 'job-title';
  title.textContent = job.title || 'Başlıksız';

  const sub = document.createElement('div');
  sub.className = 'job-sub';
  const bits = [job.sourceLabel];
  bits.push(job.mode === 'audio'
    ? `Ses ${FORMAT_LABEL[job.audioFormat] || job.audioFormat}`
    : `Video ${job.quality}p`);
  bits.push(basename(job.outDir));
  if (job.count > 1) bits.push(`${job.count} parça`);
  sub.textContent = bits.filter(Boolean).join(' · ');

  main.append(title, sub);

  const isActive = ACTIVE_STATES.has(job.status);
  const showBar = isActive || job.status === 'done' || job.status === 'partial';

  if (showBar) {
    const bar = document.createElement('div');
    bar.className = 'job-bar';
    bar.setAttribute('role', 'progressbar');
    bar.setAttribute('aria-valuemin', '0');
    bar.setAttribute('aria-valuemax', '100');
    const pct = job.status === 'done' ? 100 : (job.progress && job.progress.pct);
    if (pct != null) bar.setAttribute('aria-valuenow', String(Math.round(pct)));
    const fill = document.createElement('div');
    fill.className = 'job-bar-fill';
    fill.style.width = `${pct == null ? 0 : Math.max(0, Math.min(100, Math.round(pct)))}%`;
    bar.append(fill);
    main.append(bar);
  }

  const statusLine = document.createElement('div');
  statusLine.className = 'job-status';

  const addPart = (text, strong) => {
    if (!text) return;
    const span = document.createElement('span');
    span.className = strong ? 'strong' : '';
    span.textContent = text;
    statusLine.append(span);
  };

  if (job.status === 'downloading') {
    if (job.phase && PHASE_LABEL[job.phase]) addPart(PHASE_LABEL[job.phase], true);
    else addPart(fmtPct(job.progress && job.progress.pct), true);
    if (job.progress && job.progress.speed) addPart(`${fmtSize(job.progress.speed)}/sn`);
    if (job.progress && job.progress.eta != null && job.progress.eta > 0) addPart(`kalan ${fmtDur(job.progress.eta)}`);
    if (job.item && job.item.count) addPart(`parça ${job.item.index}/${job.item.count}`);
    addPart('İndiriliyor');
  } else if (job.status === 'queued') {
    addPart('Sırada', true);
  } else if (job.status === 'done') {
    addPart('Tamamlandı', true);
    addPart(job.files && job.files.length ? `${job.files.length} dosya` : '');
  } else if (job.status === 'partial') {
    addPart(`${job.files ? job.files.length : 0} dosya indi`, true);
  } else {
    addPart(STATUS_LABEL[job.status] || job.status, true);
    if (job.status === 'interrupted') addPart('uygulama kapanırken');
  }

  if (statusLine.childNodes.length) main.append(statusLine);

  if (job.error && (job.status === 'error' || job.status === 'partial' || job.status === 'interrupted' || job.status === 'canceled')) {
    const err = document.createElement('div');
    err.className = 'job-error';
    err.textContent = job.error;
    main.append(err);
  }

  if (job.note && job.status === 'done') {
    const note = document.createElement('div');
    note.className = 'job-note';
    note.textContent = job.note;
    main.append(note);
  }

  if (job.files && job.files.length && FINISHED_STATES.has(job.status)) {
    const list = document.createElement('ul');
    list.className = 'job-files';
    job.files.slice(0, 5).forEach((f) => {
      const li = document.createElement('li');
      li.className = 'job-file';
      const nm = document.createElement('span');
      nm.className = 'job-file-name';
      nm.textContent = basename(f);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'btn btn-quiet';
      btn.dataset.act = 'reveal';
      btn.dataset.path = f;
      btn.textContent = 'Klasörde göster';
      li.append(nm, btn);
      list.append(li);
    });
    if (job.files.length > 5) {
      const li = document.createElement('li');
      li.className = 'job-file';
      const nm = document.createElement('span');
      nm.className = 'job-file-name';
      nm.textContent = `ve ${job.files.length - 5} dosya daha`;
      li.append(nm);
      list.append(li);
    }
    main.append(list);
  }

  const actions = document.createElement('div');
  actions.className = 'job-actions';
  const mkBtn = (label, act, data) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn';
    b.dataset.act = act;
    if (data && data.id) b.dataset.id = data.id;
    if (data && data.path) b.dataset.path = data.path;
    b.textContent = label;
    actions.append(b);
    return b;
  };

  if (forHistory) {
    if (job.status === 'error' || job.status === 'canceled' || job.status === 'interrupted') {
      mkBtn('Tekrar dene', 'retry', { id: job.id });
    }
    if (job.files && job.files.length) mkBtn('Klasörü aç', 'folder', { path: job.files[0] });
    mkBtn('Kaldır', 'remove', { id: job.id });
  } else {
    mkBtn('İptal', 'cancel', { id: job.id });
  }

  row.append(folio, thumb, main, actions);
  return row;
}

function sortedByTime(jobs, desc) {
  return jobs.slice().sort((a, b) => (desc ? b.createdAt - a.createdAt : a.createdAt - b.createdAt));
}

function renderQueue() {
  const active = sortedByTime(S.queue.filter((j) => ACTIVE_STATES.has(j.status)), false);
  el.queueList.replaceChildren();
  active.forEach((job, i) => el.queueList.append(jobRow(job, i, false)));
  el.queueEmpty.hidden = active.length > 0;

  const downloading = active.filter((j) => j.status === 'downloading').length;
  const waiting = active.filter((j) => j.status === 'queued').length;
  const parts = [];
  if (downloading) parts.push(`${downloading} indirme sürüyor`);
  if (waiting) parts.push(`${waiting} sırada`);
  el.queueMeta.textContent = parts.join(' · ');
}

function renderHistory() {
  const done = sortedByTime(S.queue.filter((j) => FINISHED_STATES.has(j.status)), true);
  el.historyList.replaceChildren();
  done.forEach((job, i) => el.historyList.append(jobRow(job, i, true)));
  el.historyEmpty.hidden = done.length > 0;
  el.clearHistoryBtn.disabled = done.length === 0;
}

function renderBadges() {
  const activeCount = S.queue.filter((j) => ACTIVE_STATES.has(j.status)).length;
  const historyCount = S.queue.filter((j) => FINISHED_STATES.has(j.status)).length;
  const ab = document.querySelector('[data-badge="active"]');
  const hb = document.querySelector('[data-badge="history"]');
  ab.textContent = String(activeCount);
  ab.hidden = activeCount === 0;
  hb.textContent = String(historyCount);
  hb.hidden = historyCount === 0;
}

function scheduleRender() {
  if (renderHandle) return;
  renderHandle = requestAnimationFrame(() => {
    renderHandle = null;
    renderQueue();
    renderHistory();
    renderBadges();
  });
}

function upsertJob(job) {
  const i = S.queue.findIndex((j) => j.id === job.id);
  if (i === -1) S.queue.push(job);
  else S.queue[i] = job;
  scheduleRender();
}

/* ----------------------------------------------------------------- ayarlar */

function renderSettings() {
  const s = S.settings;
  if (!s) return;

  el.outDirValue.textContent = s.outDir;
  if (document.activeElement !== el.fileTemplate) el.fileTemplate.value = s.fileTemplate;
  el.fileTemplateEcho.textContent = s.fileTemplate;
  el.maxConcurrent.value = String(s.maxConcurrent);
  el.cookies.value = s.cookies;
  $$('input[name="theme"]').forEach((r) => { r.checked = r.value === s.theme; });

  const y = S.bins.ytDlp;
  el.ytDlpValue.textContent = y
    ? `${y.version} · ${SOURCE_LABEL[y.source] || y.source}`
    : 'Bulunamadı. İndirip kurun.';
  el.installYtDlpBtn.disabled = Boolean(y);
  el.installYtDlpBtn.textContent = y ? 'Kurulu' : 'İndir ve kur';

  const f = S.bins.ffmpeg;
  el.ffmpegValue.textContent = f
    ? `${f.version} · ${SOURCE_LABEL[f.source] || f.source}`
    : 'Bulunamadı. MP3, birleştirme ve kapak gömme için gerekli.';
  el.installFfmpegBtn.disabled = Boolean(f);
  el.installFfmpegBtn.textContent = f ? 'Kurulu' : 'İndir ve kur';
}

function updateBinNotice() {
  const missing = !S.bins.ytDlp;
  el.binNotice.hidden = !missing;
  if (missing) {
    el.binNoticeText.textContent = 'yt-dlp bulunamadı. İndirme motoru olmadan hiçbir link çalışmaz. Resmi yayından indirip kurabilirsiniz.';
  }
}

async function installBin(which) {
  const btn = which === 'ffmpeg' ? el.installFfmpegBtn : el.installYtDlpBtn;
  const prog = which === 'ffmpeg' ? el.ffmpegProgress : el.ytDlpProgress;
  const fill = which === 'ffmpeg' ? el.ffmpegProgressFill : el.ytDlpProgressFill;
  btn.disabled = true;
  prog.hidden = false;
  fill.style.width = '0%';
  announce(which === 'ffmpeg' ? 'FFmpeg indiriliyor' : 'yt-dlp indiriliyor');
  try {
    const res = await api.installBin(which);
    if (!res.ok) {
      announce(`Kurulum başarısız: ${res.error}`);
      const target = which === 'ffmpeg' ? el.ffmpegValue : el.ytDlpValue;
      target.textContent = `Kurulum başarısız: ${res.error}`;
    } else {
      announce(`${which === 'ffmpeg' ? 'FFmpeg' : 'yt-dlp'} kuruldu`);
    }
  } catch (e) {
    announce(`Kurulum başarısız: ${e.message}`);
  } finally {
    prog.hidden = true;
    btn.disabled = Boolean(which === 'ffmpeg' ? S.bins.ffmpeg : S.bins.ytDlp);
  }
}

/* ------------------------------------------------------------------ analiz */

async function runAnalyze(rawUrl) {
  const url = String(rawUrl || '').trim();
  if (!url) {
    showAnalyzeError('Önce bir link yapıştırın.');
    el.linkInput.focus();
    return;
  }

  clearAnalyzeError();
  showAnalyzeLoading(loadingTextFor(url));
  try {
    const res = await api.analyze(url);
    baseAnalysis = res;
    analysis = res;
    hideAnalyzeLoading();
    renderPreview();
    announce(`${res.title} çözümlendi`);
    el.startBtn.focus();
  } catch (e) {
    showAnalyzeError(e && e.message ? e.message : String(e));
    analysis = null;
    baseAnalysis = null;
    renderPreview();
  }
}

async function startJob() {
  if (!analysis) return;
  const mode = (document.querySelector('input[name="mode"]:checked') || {}).value || 'audio';
  const options = {
    mode,
    audioFormat: el.audioFormat.value,
    quality: el.videoQuality.value,
    outDir: S.settings ? S.settings.outDir : undefined,
  };
  try {
    const job = await api.addJob(analysis, options);
    upsertJob(job);
    announce(`${job.title} kuyruğa eklendi`);
    analysis = null;
    baseAnalysis = null;
    el.preview.hidden = true;
    el.linkInput.value = '';
    el.linkInput.focus();
    renderQueue();
  } catch (e) {
    showAnalyzeError(e && e.message ? e.message : String(e));
  }
}

/* ----------------------------------------------------------------- olaylar */

function bindEvents() {
  el.navBtns.forEach((btn) => btn.addEventListener('click', () => setView(btn.dataset.view)));

  el.linkForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!analyzing) runAnalyze(el.linkInput.value);
  });

  el.analyzeRetryBtn.addEventListener('click', () => runAnalyze(el.linkInput.value));

  el.discardBtn.addEventListener('click', () => {
    analysis = null;
    baseAnalysis = null;
    renderPreview();
    clearAnalyzeError();
    el.linkInput.focus();
  });

  el.startBtn.addEventListener('click', startJob);

  $$('input[name="mode"]').forEach((r) => r.addEventListener('change', renderOptions));
  el.audioFormat.addEventListener('change', renderOptions);
  el.videoQuality.addEventListener('change', renderOptions);

  el.wholePlaylist.addEventListener('change', async () => {
    if (!baseAnalysis || !baseAnalysis.playlistUrl) return;
    if (el.wholePlaylist.checked) {
      showAnalyzeLoading('Liste okunuyor, parça başlıkları getiriliyor…');
      try {
        const list = await api.analyze(baseAnalysis.playlistUrl);
        list.wholeList = true;
        baseAnalysis = list;
        analysis = list;
        hideAnalyzeLoading();
        renderPreview();
      } catch (e) {
        showAnalyzeError(e && e.message ? e.message : String(e));
        el.wholePlaylist.checked = false;
        analysis = baseAnalysis;
        renderPreview();
      }
    } else {
      analysis = baseAnalysis;
      renderPreview();
    }
  });

  const listHandler = (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const act = btn.dataset.act;
    const id = btn.dataset.id;
    const path = btn.dataset.path;
    if (act === 'cancel') api.cancel(id);
    else if (act === 'retry') api.retry(id);
    else if (act === 'remove') api.remove(id);
    else if (act === 'reveal') api.reveal(path || '');
    else if (act === 'folder') api.openPath(path || '');
  };
  el.queueList.addEventListener('click', listHandler);
  el.historyList.addEventListener('click', listHandler);

  el.clearHistoryBtn.addEventListener('click', () => api.clearHistory());

  el.pickFolderBtn.addEventListener('click', async () => {
    const dir = await api.pickFolder();
    if (dir) api.saveSettings({ outDir: dir });
  });

  el.fileTemplate.addEventListener('change', () => {
    const v = el.fileTemplate.value.trim() || '%(title)s.%(ext)s';
    api.saveSettings({ fileTemplate: v });
  });

  el.maxConcurrent.addEventListener('change', () => {
    api.saveSettings({ maxConcurrent: Number(el.maxConcurrent.value) || 2 });
  });

  el.cookies.addEventListener('change', () => {
    api.saveSettings({ cookies: el.cookies.value });
  });

  $$('input[name="theme"]').forEach((r) => r.addEventListener('change', () => {
    if (r.checked) api.saveSettings({ theme: r.value });
  }));

  el.installYtDlpBtn.addEventListener('click', () => installBin('ytdlp'));
  el.installFfmpegBtn.addEventListener('click', () => installBin('ffmpeg'));
  el.binNoticeBtn.addEventListener('click', () => installBin('ytdlp'));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && currentView === 'download' && analysis && !analyzing) {
      el.discardBtn.click();
    }
    if (e.key === 'Enter' && e.ctrlKey && currentView === 'download' && analysis) {
      startJob();
    }
  });
}

function bindApi() {
  if (!api) return;

  api.on('job', (job) => {
    const prev = S.queue.find((j) => j.id === job.id);
    const before = prev ? prev.status : null;
    upsertJob(job);
    if (before && before !== job.status) {
      if (job.status === 'done') announce(`${job.title} tamamlandı`);
      else if (job.status === 'error') announce(`${job.title} hata verdi`);
      else if (job.status === 'canceled') announce(`${job.title} iptal edildi`);
    }
  });

  api.on('job:removed', ({ id }) => {
    S.queue = S.queue.filter((j) => j.id !== id);
    scheduleRender();
  });

  api.on('queue:cleared', () => {
    S.queue = S.queue.filter((j) => ACTIVE_STATES.has(j.status));
    scheduleRender();
  });

  api.on('settings', (s) => {
    S.settings = s;
    applyTheme(s.theme);
    renderSettings();
    updateBinNotice();
  });

  api.on('bins', (b) => {
    S.bins = b;
    renderSettings();
    updateBinNotice();
    renderOptions();
  });

  api.on('bin:progress', ({ which, done, total }) => {
    const fill = which === 'ffmpeg' ? el.ffmpegProgressFill : el.ytDlpProgressFill;
    const pct = total ? Math.round((done / total) * 100) : 0;
    fill.style.width = `${pct}%`;
  });

  api.on('bin:done', () => {
    renderSettings();
    updateBinNotice();
    renderOptions();
  });
}

async function boot() {
  if (!api) {
    el.noApp.hidden = false;
    return;
  }
  bindApi();
  try {
    const st = await api.state();
    S.settings = st.settings;
    S.bins = st.bins;
    S.queue = st.queue || [];
    applyTheme(S.settings.theme);
    el.audioFormat.value = S.settings.audioFormat;
    el.videoQuality.value = S.settings.videoQuality;
  } catch (e) {
    el.analyzeErrorText.textContent = `Uygulama durumu okunamadı: ${e.message}`;
    el.analyzeError.hidden = false;
  }
  renderSettings();
  renderQueue();
  renderHistory();
  renderBadges();
  updateBinNotice();
  renderOptions();
}

bindEvents();
boot();
